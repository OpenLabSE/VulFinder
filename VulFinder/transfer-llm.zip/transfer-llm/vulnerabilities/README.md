Each .txt file presents the details of the client project and vulnerability (i.e. calleeMethod.evosuite_target, VF in the paper and  calleeMethod.test, L^T in the paper)

The urls to the client projects are given in https://github.com/testmimic/transfer/blob/main/cases_considered.md.
After obtaining the client project source code, they can be compiled and built.
The calleeMethod.evosuite_target files should be in the directory from which TRANSFER is invoked.

The run.sh files are examples of how TRANSFER should be invoked for the client projects.

