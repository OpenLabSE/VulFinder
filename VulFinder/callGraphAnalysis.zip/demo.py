from complexity.compute import dedent
from radon.visitors import CognitiveComplexityVisitor

code = """
try:
    1 / 0
except ZeroDivisionError:
    print
except TypeError:
    pass


class J(object):

    def aux(self, w):
        if w == 0:
            return 0
        return w - 1 + sum(self.aux(w - 3 - i) for i in range(2))


def f(a, b):
    def inner(n):
        return n ** 2

    if a < b:
        b, a = a, inner(b)
    return a, b
"""

visitor = CognitiveComplexityVisitor.from_code(dedent(code), off=False)
print(visitor)