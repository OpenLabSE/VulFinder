# coding=utf-8
# @Time : 2024/7/5 10:37
# @Author : RoseLee
# @File : 单行代码测试用例生成
# @Project : agent-study
import autogen
import pandas as pd
logfile = './log.json'

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]

if __name__ == '__main__':
    bug_name='tf.constant'
    df = pd.read_excel('./function_to_scan/Bert_func_to_test .xlsx',sheet_name=bug_name)
    bug_info=f"tf.constant函数的参数包括value和dtype，在调用tf.constant函数时，若将参数value分配字符串，参数dtype指定为tf.float16时，则会出现错误。"
    for row in df['location']:
        print(row.split(':')[2])
        assistant_prompt=f"""
        你是一个测试用例生成专家，你的职责是帮助用户对待测代码生成可以触发漏洞的测试输入。
        首先，你需要了解以下几个关键字的具体含义，
            漏洞api：漏洞api是tensorflow库中一些库函数，这些库函数在被调用时若传入了某些满足触发信息的参数则会发生错误，如tf.concat函数。
            待测代码：会在下文给出，待测代码中调用了一些漏洞api，只包含一行代码。在运行待测代码时很可能会因为调用漏洞api时，设置了不恰当的参数从而导致漏洞api发生错误。
            触发信息：触发信息中描述了在调用漏洞api的过程中，如何设置参数会使漏洞api出现错误。
            测试用例：测试用例是面向待测代码的，在待测代码中，会使用到上文所声明的局部变量，这些变量很可能会被设置为待测代码调用漏洞api的参数，从而引发漏洞api发生错误。
                因此，你只需要关注这些充当调用漏洞api参数的局部变量，并根据这些局部变量生成可以触发漏洞api发生错误的测试用例。
        在生成测试用例时，你需要注意以下几点：
            1.若可以为待测代码生成触发漏洞api发生错误的测试用例，那么生成的测试用例数量越多越好（最少10个），尽可能覆盖所有可能触发api漏洞的情况。
            2.在生成测试输入的过程中，你需要严格参考漏洞api的触发信息，以提升生成测试用例的质量。
            3.生成测试用例的步骤为分析测试代码定位漏洞api的位置->分析当前待测代码中所包含的局部变量->找出所有调用漏洞api参数中的局部变量->若漏洞api中存在未知局部变量，
            则根据漏洞触发信息为这些局部变量生成测试用例
            5.当调用漏洞api时，若漏洞api的参数中没有变量（可能只有常数），那么你只需要根据触发信息关注当前一种情况下，是否会触发漏洞api发生错误，若不满足条件，则该待
            测代码无法生成可以触发漏洞api出错的测试用例。例如ds = tf.constant([[1, 5, 9], [1, 5, 0]])，该待测代码调用漏洞api所传参数都为常数，不要为了迎合漏
            洞触发信息而在生成测试用例时擅自改变原代码内容。
            6.测试用例的内容应该与待测代码调用漏洞api时所设置的变量参数一一对应，例如x=mtf.pow(mtf.constant(a, 1, dtype = b), c)该代码中出现了三个局部变量a，
            b，c但是调用漏洞api mtf.constant时，设置的参数为(a, 10000, dtype = b)，由此可知，变量c的内容与tf.constant是否出现错误无关，因此你生成的测试用例应该是针对变量a与变量b的。
        下面是一个例子：
        待测代码：x = tf.get_variable(x.da, meck, initializer=tf.constant_initializer(0)),
        漏洞api名：tf.constant，
        触发信息：tf.constant函数的参数包括value和dtype，在调用时，将tf.constant的参数value设置为字符串，将tf.constant的参数dtype指定为tf.float16时，则会出现错误。
        这段代码中，调用了可能触发漏洞的函数tf.constant_initializer，涉及的所有变量包括x.da , meck。你首先需要判断漏洞api的位置，其次根
        据给出的漏洞api的触发信息判断这些变量会不会诱使tf.constant_initializer触发漏洞。然后根据被设置为漏洞api参数的上下文变量生成测试用例。
            对于上面这个例子，经过分析发现，该待测代码调用tf.constant_initializer函数时，将漏洞api的参数设置为常数，因此该待测代码中其他变量都与漏洞出发无关，而根
        据触发信息可知，调用tf.constant_initializer时设置参数为0不满足触发信息，因此不会触发该漏洞api出现错误。可知对于该待测代码，无法生成触发漏洞api发生错误的测
        试用例。此时，由于无法生成测试用例，你需要将分析结果告知用户，注意一定要将结果告知，以便阻止verifier进行验证。
        
        接下来你需要根据下面的信息生成对于的测试用例，
        待测代码：{row.split(':')[2]}
        相关漏洞名为：{bug_name}
        触发信息为：{bug_info}  
        当你生成完测试用例之后，将其提交给verifier，并要求verifier对你生成的测试用例进行验证
        """
        verifier_prompt = f"""
        你是一个测试用例验证专家，你需要获取assistant所生成的测试用例，得到测试用例之后，你需要将每个测试用例分别输入到待测代码行进行运行，
        验证每个测试用例是否能够触发漏洞并给出判断，对于每一个测试用例，需要生成一段描述信息，来描述当前测试用例是否可以触发漏洞以及原因。
        然后你需要总结测试用例
        （待测代码行和漏洞触发信息都会在下文给出）。
        待测代码行：{row.split(':')[2]}
        相关漏洞名为：{bug_name}
        该漏洞的触发条件为：{bug_info}     
        """
        message = f"""
        请为待测代码生成可以触发漏洞api的测试输入，并对每个生成的测试用例进行验证，最后将所有有效的测试用例返回给用户，
        并附上每个测试用例能否触发漏洞的描述。
        如果可以为待测代码生成测试用例，那么结果应该按照以下格式：
            测试用例1：x=3，a=2
            测试用例2：x=4，a=3
            ···
            """
        agentchat(assistant_prompt=assistant_prompt, verifier_prompt=verifier_prompt, message=message)









