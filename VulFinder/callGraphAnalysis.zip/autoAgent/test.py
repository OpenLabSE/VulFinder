function_name0 = """model_fn(features, labels, mode, params)"""
function_params0 = """features, labels, mode, params"""
function_code0 = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""
call_line0 = """x = tf.reshape(x, feature_shape.to_integer_list)"""


function_name = """embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False)"""
function_params = """input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False"""

function_code = """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""

call_line = """output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])"""

code_line_values = """[1 for i in range(256)]"""
code_line_params = """input_shape"""

line_explain = """, 其中, 函数to_integer_list用于将某种数据结构（如字符串、列表或其他可迭代对象）转换为整数列表"""

assign_statements = """
input_ids = tf.expand_dims(input_ids, axis=[-1])
input_shape = get_shape_list(input_ids)
"""

message = f"""
{function_code}
以上为目标函数{function_name}的代码片段. 
目标函数的输入变量为 {function_params}
请判断目标代码行 {call_line} 中变量{code_line_params}的是否可能为预设变量值{code_line_values}。 若可能，请推断出目标函数的输入值，使得目标函数在执行到目标代码行后产生的变量信息与预设变量值一致。
若不可能，请提供解释说明。
"""

message = f"""
### Target Function Code:
{function_name}

### Target Function Signature:
{function_name}

### Your Task:
Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
values at the Target Code Line is consistent with the default variable values. 
The format of the output is: 
Target function input values 1: param1 = xxx, param2 =.. , 
Target function input values 2: param1 = xxx, param2 =.. , 
"""
print(message)