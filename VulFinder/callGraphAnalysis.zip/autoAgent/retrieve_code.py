import os
import chromadb
import autogen
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]

assistant = RetrieveAssistantAgent(
    name="assistant",
    system_message="你现在需要的是要求ragproxyagent来检测目标文档中的tf.random方法的地方并标出来",
    human_input_mode="NEVER",
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    }
)
ragproxyagent = RetrieveUserProxyAgent(
    name="ragproxyagent",
    human_input_mode="NEVER",  # 默认情况下，human_input_mode为“ALWAYS”，这意味着代理将在每一步请求人工输入。我们在这里设置为“NEVER”。
    max_consecutive_auto_reply=3,
    system_message="你的任务就是根据所指定的文档进行相关信息的检索",
    retrieve_config={
        "task": "code",  # 'task'表示我们正在处理的任务类型。在这个例子中，它是一个“代码”任务
        "docs_path": [  # 'docs_path'是docs目录的路径。它也可以是单个文件的路径，或者单个文件的url。默认情况下,它被设置为None，只有在集合已经创建时才有效。
            "./test.md",

            os.path.join(os.path.abspath(""), "..", "website", "docs"),
        ],
        "custom_text_types": ["non-exist -type"],
        # ' custom_text_types '是要处理的文件类型列表。默认为' autogen.retrieve_utils.TEXT_FORMATS '。这只适用于' docs_path '目录下的文件。显式包含的文件和url将被分块，无论其类型如何。在本例中，我们将其设置为["non-exist -type"]即只处理markdown文件。由于“web /docs”中没有包含“non-exist -type”的文件，没有文件将被处理。但是，显式包含的url仍将被处理。

        "chunk_token_size": 2000,
        "model": config_list[0]["model"],  # 用用户给的apikey对应的模型
        "vector_db": "chroma",
        "overwrite": True,
    },
    code_execution_config=False,  # set to False if you don't want to execute the code
)

problem="有哪些函数调用了tf.random接口"
chat_result = ragproxyagent.initiate_chat(
    assistant, message=ragproxyagent.message_generator, problem=problem
)
