import autogen

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]
bug_name = "tf.reshape"
bug_info = """
TensorFlow提供了函数 tf.reshape(tensor, shape, name=None)。其中，参数tensor为一个张量；参数shape指定目标形状，类型可以为list、tuple或tf.Tensor。
当参数shape的类型为list，且list的元素个数(列表长度)超过255时会触发漏洞。
以下为一个相关的漏洞触发程序的示例
```
import tensorflow as tf
tf.reshape(tensor=[[1]],shape=tf.constant([0 for i in range(255)], dtype=tf.int64))
```
"""

test_case_generator = autogen.AssistantAgent(
    name="generator",
    system_message=f"""
    你是一个乐于助人的代码检测助手,首先你要理解以下信息：TensorFlow库中有一些函数存在漏洞，他们在调用不当的情况下会出现错误.
    给定一个目标函数，其中存在对TensorFlow漏洞函数的代码调用. 你要做的就是判断目标函数是否可以触发TensorFlow的函数的漏洞。
    若可以触发，对给定的目标函数生成相关的测试输入。这些测试输入应该要有多个且不能重复，这些测试输入均可以TensorFlow漏洞函数的漏洞。
    请注意，如果目标函数调用了TensorFlow漏洞函数，但是无论哪种测试输入都不会触发漏洞，那么你不需要返回测试用例，只需返回TERMINATE。
    你需要等待用户输入目标函数，不需要自己生成函数，每当你生成测试输入之后，你需要等待用户的验证结果。
    若验证失败，根据用户返回的失败信息和相关的测试输入重新生成新的测试输入。
    若验证成功，则返回TERMINATE。
    具体的漏洞函数信息会在下面给出：
    {bug_info}
    请至少生成2个测试用例，当然测试用例数量越多越好，尽可能覆盖所有情况
    如果任何测试输入都无法触发漏洞，那么你只需返回提示信息不需要返回测试输入
    注意，你生成的每一个测试输入，都要严格根据函数的参数列表生成，下面是一个例子函数：
    def sum(a,b):
        ...
        ...
        return x
    那么你生成的测试输入的格式应该是：
    测试用例1：a=2,b=3
    测试用例2：a=3，b=10
    ...
    在测试用例生成后，将测试用例交给user_proxy进行验证，如果user_proxy验证失败，那么你需要根据返回的失败信息和相关的测试输入重新生成测试用例。
    若验证成功或无法生成新的测试输入，则向user_proxy发送"停止"。
    """,
    llm_config={
        "cache_seed": 42,
        "config_list": config_list,
        "timeout": 1600,
    }

)
# test_case_verifier = autogen.UserProxyAgent(
#     name="verifier",
#     human_input_mode="NEVER",
#     system_message="""
#         你的职责是获取generator传来的测试用例，和user_proxy传入的代码，你需要将测试用例传入代码并运行，看是否会触发漏洞api，若触发失败，则对该测试用例进行标记。
#         若触发成功，则将当前测试用例返回给user_proxy，generator对一个待测代码生成的所有测试用例运行完毕之后，一齐将结果交给user_proxy。注意，请等待测试用例运行完成之后，再返回信息""",
#     llm_config={
#         "cache_seed": 42,
#         "config_list": config_list,
#         "timeout": 1600,
#     },
#     code_execution_config={"use_docker": False}
#
# )
user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    system_message=f"""
        你是一个乐于助人的代码检测助手,首先你要理解以下信息：
        {bug_info}
        你的任务是，从用户处获取目标函数代码，交给generator，并接受generator返回的测试用例，进行运行，查看每个测试用例是否能够成功触发api漏洞，
        如果经过运行发现有某个测试用例无法触发bug，则将此测试用例以及相关的失败信息交给generator，
        并要求generator生成新的测试用例，直到generator认为他生成的测试用例已经足够涵盖所有情况，发送给你"停止"。
        此时你应该输出所有的有效测试用例.
    """,
    human_input_mode="NEVER",
    code_execution_config={"use_docker": False}
)
# groupchat = autogen.GroupChat(
#     agents=[user_proxy, test_case_generator, test_case_verifier], messages=[])
# manager = autogen.GroupChatManager(
#     groupchat=groupchat,
#     llm_config={
#         "cache_seed": 42,
#         "config_list": config_list,
#         "timeout": 1600,
#     })

function = """
def mlm_sample_text(params, x, random_documents=False):
    seed = params.get('seed', None)
    ctx_len = params["n_ctx"]
    assert 'mlm_mask_id' in params, 'the key `mlm_mask_id` must be set on your config to do masked language model training, specifying the id of the reserved mask token'

    mask_id = params['mlm_mask_id']
    cls_token_id = params.get('mlm_cls_token_id', None)
    num_tokens = params.get('n_vocab', None)

    mask_ignore_ids = set(params.get('mlm_mask_ignore_ids', []))
    mask_ignore_ids.add(cls_token_id)

    mask_prob = params.get('mlm_mask_prob', 0.15)
    same_token_prob = params.get('mlm_same_token_prob', 0.10)
    random_token_prob = params.get('mlm_random_token_prob', 0.)

    seq_len = ctx_len if cls_token_id is None else (ctx_len - 1)

    if random_documents:
        s = tf.size(x)
        r = tf.random.uniform([], maxval=(s - seq_len), dtype=tf.dtypes.int32, seed=seed)
        r1 = tf.range(r, r + seq_len)
        r1 = tf.reshape(r1, [seq_len])
        features = tf.gather(x, r1)
    else:
        features = x[:seq_len]

    # add cls token id if specified by `mlm_cls_token_id`
    if cls_token_id is not None:
        features = tf.pad(features, [[1, 0]], constant_values=cls_token_id)

    features = tf.cast(features, dtype=tf.int32)
    shape = features.shape

    # determine which tokens are mask-able
    can_mask = tf.not_equal(features, 0)
    for ignore_id in mask_ignore_ids:
        can_mask &= tf.not_equal(features, ignore_id)

    # generate boolean mask for masking ids
    mask_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed), mask_prob)
    mask_mask &= can_mask

    # generate mask for actually replacing the tokens, for allowing a small number of tokens to stay the same
    replace_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed),
                           1 - same_token_prob)

    # randomly replace some tokens with random tokens before masking
    if random_token_prob > 0:
        random_token_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed),
                                    random_token_prob)
        random_tokens = tf.random.uniform(shape, minval=1, maxval=num_tokens, dtype=tf.dtypes.int32, seed=seed)

        # make sure random tokens do not include illegal token ids specified by `mlm_mask_ignore_ids`
        random_can_mask = tf.not_equal(random_tokens, 0)
        for ignore_id in mask_ignore_ids:
            random_can_mask &= tf.not_equal(random_tokens, ignore_id)

        features = tf.where(random_token_mask & random_can_mask, random_tokens, features)

    # mask the tokens
    mask_tokens = tf.ones(shape, dtype=tf.int32) * mask_id
    masked_features = tf.where(mask_mask & replace_mask, mask_tokens, features)

    # labels will be set to 0 for all non-masked tokens
    labels = tf.where(mask_mask, tf.zeros(shape, dtype=tf.int32), features)

    masked_features, labels = map(lambda t: tf.reshape(t, [ctx_len]), (masked_features, labels))
    return masked_features, labels
"""
call_line = """
r1 = tf.reshape(r1, [seq_len])
"""

inner_trans = """
ctx_len -> seq_len
cls_token_id -> seq_len
x -> s
s -> r
seq_len -> r
seed -> r
r -> r1
seq_len -> r1
r1 -> r1
seq_len -> r1
x -> features
r1 -> features
x -> features
seq_len -> features
features -> features
cls_token_id -> features
features -> features
features -> shape
features -> can_mask
features -> can_mask
ignore_id -> can_mask
shape -> mask_mask
seed -> mask_mask
mask_prob -> mask_mask
can_mask -> mask_mask
shape -> replace_mask
seed -> replace_mask
same_token_prob -> replace_mask
shape -> random_token_mask
seed -> random_token_mask
random_token_prob -> random_token_mask
shape -> random_tokens
num_tokens -> random_tokens
seed -> random_tokens
random_tokens -> random_can_mask
random_tokens -> random_can_mask
ignore_id -> random_can_mask
random_token_mask -> features
random_can_mask -> features
random_tokens -> features
features -> features
shape -> mask_tokens
mask_id -> mask_tokens
mask_mask -> masked_features
replace_mask -> masked_features
mask_tokens -> masked_features
features -> masked_features
mask_mask -> labels
shape -> labels
features -> labels
masked_features -> masked_features
labels -> labels
ctx_len -> masked_features
ctx_len -> labels
"""

message = f"""
为目标函数函数生成触发{bug_name}漏洞的测试输入。
注意要生成多个，尽量覆盖各种情况至少2个，描述性文字请用中文进行回答, 如果某一个参数设置成任何内容都不会影响漏洞触发，那么你返回的测试输入中的该参数应该固定不变，
并指明类型。若某些参数不影响漏洞触发，那么在文末需要进行解释。
目标代码为：{function}
其中，代码行 {call_line} 存在对 {bug_name} 函数的调用.
函数内部的控制流关系为: {inner_trans}
"""
user_proxy.initiate_chat(test_case_generator, message=message, max_turns=12)




RETRIEVE_MESSAGE_DEFAULT = """You're a retrieve augmented chatbot. You answer user's questions based on your own knowledge and the
context provided by the user. You should follow the following steps to answer a question:
Step 1, you estimate the user's intent based on the question and context. The intent can be a code generation task or
a question answering task.
Step 2, you reply based on the intent.
If you can't answer the question with or without the current context, you should reply exactly `UPDATE CONTEXT`.
If user's intent is code generation, you must obey the following rules:
Rule 1. You MUST NOT install any packages because all the packages needed are already installed.
Rule 2. You must follow the formats below to write your code:
```language
# your code
```

If user's intent is question answering, you must give as short an answer as possible.

User's question is: {{ input_question }}

Context is: {{ input_context }}
"""

RETRIEVE_MESSAGE_CODE = """You're a retrieve augmented coding assistant. You answer user's questions based on your own knowledge and the
context provided by the user.
If you can't answer the question with or without the current context, you should reply exactly `UPDATE CONTEXT`.
For code generation, you must obey the following rules:
Rule 1. You MUST NOT install any packages because all the packages needed are already installed.
Rule 2. You must follow the formats below to write your code:
```language
# your code
```

User's question is: {{ input_question }}

Context is: {{ input_context }}
"""

RETRIEVE_MESSAGE_QA = """You're a retrieve augmented chatbot. You answer user's questions based on your own knowledge and the
context provided by the user.
If you can't answer the question with or without the current context, you should reply exactly `UPDATE CONTEXT`.
You must give as short an answer as possible.

User's question is: {{ input_question }}

Context is: {{ input_context }}
"""