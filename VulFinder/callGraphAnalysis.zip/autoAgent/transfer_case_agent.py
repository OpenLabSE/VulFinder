import  autogen

user_proxy_prompt = """You are a professional user agent, you need to fully communicate the user requirements to the test case generation 
expert TG and test case validation expert TV. """

test_case_generator_prompt = """
## Background:
  There are vulnerabilities in some Java third-party libraries. Developers may call these 
library functions as they work on the project, so when the project is put into use, Some user input can trigger these vulnerabilities and 
crash the program. Now we have collected a lot of projects that call vulnerable functions of third-party libraries, and detected the 
specific call locations of vulnerable library functions in the projects. 

## Your Task:
  We will provide a description of the vulnerability including the location where the vulnerability occurs, the test case that 
can trigger the vulnerability, the signature of the target function that calls the vulnerability API, and the code context of the target 
function. You need to generate test cases for the target function that can trigger this vulnerability based on the test cases triggered 
by the vulnerability. Since this task is java oriented, the test cases you generate need to be in the form of junit unit tests. 
Here is an example that contains the information needed for the task and the steps to solve the task. 

## Example:
==> Before the task begins, you receive the following information:
# Vulnerability Information: 
An issue was discovered in Legion of the Bouncy Castle BC Java 1.65 and 1.66. The [OpenBSDBCrypt.checkPassword] utility method compared 
incorrect data when checking the password, allowing incorrect passwords to indicate they were matching with previously hashed ones that were 
different.
# The test case that can trigger the vulnerability: 
public void performTest() throws Exception{
    int costFactor = 4;
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[16];
    for (int i = 0; i < 1000; i++){
        random.nextBytes(salt);
        final String tokenString = OpenBSDBCrypt.generate("test-token".toCharArray(), salt, costFactor);
        OpenBSDBCrypt.checkPassword(tokenString, "wrong-token".toCharArray());
    }
}
# Signature of the target function: 
org.jivesoftware.openfire.auth.JDBCAuthProvider:comparePasswords(java.lang.String,java.lang.String)
# Code context of the target function:
public class JDBCAuthProvider implements AuthProvider, PropertyEventListener {

    protected boolean comparePasswords(String plainText, String hashed) {
        int lastIndex = passwordTypes.size() - 1;
        if (passwordTypes.get(lastIndex) == PasswordType.bcrypt) {
            for (int i = 0; i < lastIndex; i++) {
                plainText = hashPassword(plainText, passwordTypes.get(i));
            }
            return OpenBSDBCrypt.checkPassword(hashed, plainText.toCharArray());
        }

        return hashPassword(plainText).equals(hashed);
    }

    private String hashPassword(String password) {
        for (PasswordType type : passwordTypes) {
            password = hashPassword(password, type);
        }
        return password;
    }

    protected String hashPassword(String password, PasswordType type) {
        switch (type) {
            case md5:
                return StringUtils.hash(password, "MD5");
            case sha1:
                return StringUtils.hash(password, "SHA-1");
            case sha256:
                return StringUtils.hash(password, "SHA-256");
            case sha512:
                return StringUtils.hash(password, "SHA-512");
            case bcrypt:
                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                int cost = (bcryptCost < 4 || bcryptCost > 31) ? DEFAULT_BCRYPT_COST : bcryptCost;
                return OpenBSDBCrypt.generate(password.toCharArray(), salt, cost);
            case nt:
                try {
                  MessageDigest md = MessageDigest.getInstance("MD4");
                  byte[] utf16leBytes = password.getBytes(StandardCharsets.UTF_16LE);
                  byte[] digestBytes = md.digest(utf16leBytes);
                  return new String( Hex.encode( digestBytes ) );
                }
                catch (Exception e) {
                  return null;
                }
            case plain:
            default:
                return password;
        }
    }
}

==> After obtaining the above information, you need to generate test case for the target function:
@Test
public void testComparePasswordsVulnerability() {
    String plainText = "test-token";
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[16];
    random.nextBytes(salt);
    int costFactor = 4;
    final String hashed = OpenBSDBCrypt.generate(plainText.toCharArray(), salt, costFactor);

    // Execution
    boolean result = comparePasswords("wrong-token", hashed);

    // Verification
    assertFalse(result);
}
"""

verifier_prompt = """
## Background:
  There are vulnerabilities in some Java third-party libraries. Developers may call these 
library functions as they work on the project, so when the project is put into use, Some user input can trigger these vulnerabilities and 
crash the program. Now we have collected a lot of projects that call vulnerable functions of third-party libraries, and detected the 
specific call locations of vulnerable library functions in the projects. 

## Your Task:
Your companion, the test case generation expert - TG will generate multiple unit test cases for the target function that calls the above 
vulnerability library function. You need to take the vulnerability trigger information, the source code of the target function, and the test 
cases Etc information to judge whether the test case generated by TG is valid, if not, the TG is required to regenerate the test case. 
In the judgment process, you need to refine your logic at each step. An example will help you understand the process better.

## Example:
==> Suppose you want to verify the following test cases and information about them:
# Test case: 
@Test
public void testComparePasswordsVulnerability() {
    String plainText = "test-token";
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[16];
    random.nextBytes(salt);
    int costFactor = 4;
    final String hashed = OpenBSDBCrypt.generate(plainText.toCharArray(), salt, costFactor);

    // Execution
    boolean result = comparePasswords("wrong-token", hashed);

    // Verification
    assertFalse(result);
}
# Signature of the target function: 
org.jivesoftware.openfire.auth.JDBCAuthProvider:comparePasswords(java.lang.String,java.lang.String)
# Code context of the target function:
public class JDBCAuthProvider implements AuthProvider, PropertyEventListener {

    protected boolean comparePasswords(String plainText, String hashed) {
        int lastIndex = passwordTypes.size() - 1;
        if (passwordTypes.get(lastIndex) == PasswordType.bcrypt) {
            for (int i = 0; i < lastIndex; i++) {
                plainText = hashPassword(plainText, passwordTypes.get(i));
            }
            return OpenBSDBCrypt.checkPassword(hashed, plainText.toCharArray());
        }

        return hashPassword(plainText).equals(hashed);
    }

    private String hashPassword(String password) {
        for (PasswordType type : passwordTypes) {
            password = hashPassword(password, type);
        }
        return password;
    }

    protected String hashPassword(String password, PasswordType type) {
        switch (type) {
            case md5:
                return StringUtils.hash(password, "MD5");
            case sha1:
                return StringUtils.hash(password, "SHA-1");
            case sha256:
                return StringUtils.hash(password, "SHA-256");
            case sha512:
                return StringUtils.hash(password, "SHA-512");
            case bcrypt:
                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                int cost = (bcryptCost < 4 || bcryptCost > 31) ? DEFAULT_BCRYPT_COST : bcryptCost;
                return OpenBSDBCrypt.generate(password.toCharArray(), salt, cost);
            case nt:
                try {
                  MessageDigest md = MessageDigest.getInstance("MD4");
                  byte[] utf16leBytes = password.getBytes(StandardCharsets.UTF_16LE);
                  byte[] digestBytes = md.digest(utf16leBytes);
                  return new String( Hex.encode( digestBytes ) );
                }
                catch (Exception e) {
                  return null;
                }
            case plain:
            default:
                return password;
        }
    }
}
# Vulnerability Information: 
An issue was discovered in Legion of the Bouncy Castle BC Java 1.65 and 1.66. The [OpenBSDBCrypt.checkPassword] utility method compared 
incorrect data when checking the password, allowing incorrect passwords to indicate they were matching with previously hashed ones that were 
different.
# The test case that can trigger the vulnerability: 
public void performTest() throws Exception{
    int costFactor = 4;
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[16];
    for (int i = 0; i < 1000; i++){
        random.nextBytes(salt);
        final String tokenString = OpenBSDBCrypt.generate("test-token".toCharArray(), salt, costFactor);
        OpenBSDBCrypt.checkPassword(tokenString, "wrong-token".toCharArray());
    }
}

==> After obtaining the above information, you need to follow these steps to complete the task:
step1 : Analyze the trigger condition of the vulnerability based on the trigger example of the vulnerability.
The triggering example of the vulnerability here is:
public void performTest() throws Exception{
    int costFactor = 4;
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[16];
    for (int i = 0; i < 1000; i++){
        random.nextBytes(salt);
        final String tokenString = OpenBSDBCrypt.generate("test-token".toCharArray(), salt, costFactor);
        OpenBSDBCrypt.checkPassword(tokenString, "wrong-token".toCharArray());
    }
}
In the call OpenBSDBCrypt.checkPassword method for value "wrong-token" and many times after OpenBSDBCrypt.generate method to deal 
with the value of the "test-token" appeared inconsistent with expectations, triggered the vulnerability.
step2 : Analyze whether the test case case can execute correctly based on the code context of the target function.
The generated test program is testComparePasswordsVulnerability(), and after confirm there are no errors.
step3 : Combined with the test cases that trigger the vulnerability, it is confirmed whether the generated test cases for target funcion can 
trigger the vulnerability.
After confirmation, the generated test cases of the target function can trigger the vulnerability.
"""


config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]

def agentchat(test_case_generator_prompt,verifier_prompt,user_proxy_prompt,message):

    test_cases_generator = autogen.AssistantAgent(
        name="TG",
        system_message=test_case_generator_prompt,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",

    )
    user_proxy = autogen.UserProxyAgent(
        name="user_proxy",
        system_message=user_proxy_prompt,
        human_input_mode="ALWAYS",
        code_execution_config={"use_docker": False},
        # is_termination_msg=True,

        max_consecutive_auto_reply=5
    )
    test_case_verifier = autogen.AssistantAgent(
        name="TV",
        system_message=verifier_prompt,
        # is_termination_msg=True,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",
        max_consecutive_auto_reply=5
    )
    groupchat = autogen.GroupChat(
        agents=[user_proxy, test_case_verifier, test_cases_generator], messages=[])
    manager = autogen.GroupChatManager(
        groupchat=groupchat,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        })

    user_proxy.initiate_chat(manager, message=message, max_turns=2)
