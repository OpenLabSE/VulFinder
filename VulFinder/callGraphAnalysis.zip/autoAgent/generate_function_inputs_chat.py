from openai import OpenAI
import os
import logger
import pandas as pd

# 设置日志记录器
logger = logger.setup_logger('generate_function_inputs_chat')

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'   # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")

function_name0 = """model_fn(features, labels, mode, params)"""  # 函数签名
function_params0 = """features, labels, mode, params"""  # 函数的输入参数列表

# 函数代码
function_code0 = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""
# 目标代码行
call_line0 = """x = tf.reshape(x, feature_shape.to_integer_list)"""

# 函数内部的变量传毒关系
assign_statements0 = """
features_dict = {"inputs": features, "labels": labels}
sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}
params = add_mode_to_params(params, mode)
batch_size = get_batch_size(params)
batch_dim = mtf.Dimension("batch", batch_size)
batch_dims = [batch_dim]
feature_length = sequence_length_dict["inputs"]
length_dim = mtf.Dimension("sequence", feature_length)
feature_shape = mtf.Shape(batch_dims + [length_dim])
"""

# 目标调用代码行中变量的预设值，预设值由上一步LLM推测出
code_line_values0 = """[1 for i in range(256)]"""
# 目标代码行的目标变量，需要将目标变量的值指定为预设值
code_line_params0 = """feature_shape"""


function_name1 = """embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False)"""
function_params1 = """input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False"""
function_code1 = """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""


call_line1 = """output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])"""

code_line_values1 = """[1 for i in range(256)]"""
code_line_params1 = """input_shape"""

assign_statements1 = """
input_ids = tf.expand_dims(input_ids, axis=[-1])
input_shape = get_shape_list(input_ids)
"""

#  line_explain = """, 其中, 函数to_integer_list用于将某种数据结构（如字符串、列表或其他可迭代对象）转换为整数列表"""

function_name2 = """autoregressive_sample_text_random_documents(params, x)"""

function_code2 = """
def autoregressive_sample_text_random_documents(params, x):
  seed = params.get('seed', None)
  s = tf.size(x)
  r = tf.random.uniform([], maxval=s - (params["n_ctx"] + 1), dtype=tf.dtypes.int32, seed=seed)
  r1 = tf.range(r, r + params["n_ctx"])
  r2 = tf.range(r + 1, (r + 1) + params["n_ctx"])
  r1 = tf.reshape(r1, [params["n_ctx"]]) # Somehow, this makes the compiler happy
  r2 = tf.reshape(r2, [params[
  "n_ctx"]]) # TPUs want constant sized input, and these reshapes makes it recognize the shape of the input
  vals1 = tf.gather(x, r1)
  vals2 = tf.gather(x, r2)
 
  vals1 = tf.reshape(vals1, [params["n_ctx"]])
  vals2 = tf.reshape(vals2, [params["n_ctx"]])
  vals1 = tf.cast(vals1, dtype=tf.int32)
  vals2 = tf.cast(vals2, dtype=tf.int32)
  return vals1, vals2
"""

call_line2 = """r1 = tf.range(r, r + params["n_ctx"])"""

code_line_params2 = """n_ctx"""
code_line_values2 = """-1e+38"""

target_function_gpt_neo = pd.read_excel('../data/target_function_info1.xlsx', sheet_name='Sheet1')

for index, row in target_function_gpt_neo.iterrows():
    function_name = row['function_name']
    function_params = row['function_params']
    function_code = row['function_code']
    call_line = row['call_line']
    code_line_params = row['code_line_params']
    assign_statements = row['assign_statements']
    if assign_statements == 0:
        assign_statements_context = ''
    else:
        assign_statements_context = f"""
    ### Internal Variables Passing within Target Function:
    {assign_statements}
    """

    message1 = f"""
    ### Target Function Signature:
    {function_name}
    
    ### Target Function Code:
    {function_code}
    
    ### Target Code Line:
    {call_line}
    {assign_statements_context}
    
    ### Example:
    For example function:
    def sum(a,b):
            x = a + b
            return x
    target line is: x = a + b
    and the variable in the code line is x=10
    Your output should be:
    Target Function inputs 1: a = 1, b = 9
    Target Function inputs 2: a = -1, b = 11
    
    ### Your Task:
    Check whether the variable in the Target Code Line #{call_line}# is likely to be the default value #{code_line_params}#. 
    If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
    values at the Target Code Line is consistent with the default variable values. 
    The format of the output is: 
    Target function input values 1: param1 = xxx, param2 =.. , 
    Target function input values 2: param1 = xxx, param2 =.. , 
    """

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert in code understanding and detection. You need to generate input for the "
                                          "function that might trigger a bug in the target function based on the information you're "
                                          "provided."},
            {"role": "user", "content": message1}
        ],
        temperature=0.7
    )

    answer1 = response.choices[0].message.content
    print(answer1)
    logger.info(f"Prompt: {message1}")
    logger.info(f"Answer:\n {answer1}")

# response1 = client.chat.completions.create(
#     model="gpt-3.5-turbo",
#     messages=[
#         {"role": "system", "content": "You are an expert in code understanding and detection."},
#         {"role": "user", "content": "Who won the world series in 2020?"},
#         {"role": "assistant", "content": f"{answer1}"},
#         {"role": "user", "content": "Where was it played?"}
#     ],
#     temperature=0.7
# )
# print(response1.choices[0].message.content)
# logger.info(response1.choices[0].message.content)
