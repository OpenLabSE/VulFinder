from openai import OpenAI
import os
import logger
import pandas as pd

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'  # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")

vulnerable_test_case = """
import torch
t = torch.tensor([])
t.median()
"""

code_context = """
    public CloseableHttpResponse execute(
            final HttpUriRequest request,
            final HttpContext context) throws IOException, ClientProtocolException {
        Args.notNull(request, "HTTP request");
        return doExecute(determineTarget(request), request, context);
    }
    
    private static HttpHost determineTarget(final HttpUriRequest request) throws ClientProtocolException {
        HttpHost target = null;
        final URI requestURI = request.getURI();
        if (requestURI.isAbsolute()) {
            target = extractHost(requestURI);
            if (target == null) {
                throw new ClientProtocolException("URI does not specify a valid host name: "
                        + requestURI);
            }
        }
        return target;
    }
    """

target_function = """
class SmoothedValue(object):
    def __init__(self, window_size=20, fmt=None):
        if fmt is None:
            fmt = "{median:.6f} ({global_avg:.6f})"
        self.deque = deque(maxlen=window_size)
        self.total = 0.0
        self.count = 0
        self.fmt = fmt

    @property
    def median(self):
        d = torch.tensor(list(self.deque))
        return d.median().item()
"""

message1 = f"""
# vulnerability test case: {vulnerable_test_case}
Attempting to find median of an empty tensor should cause a RuntimeError.

# target program:{target_function}

There is a vulnerability in the #torch.median()# method, and the vulnerability test case could trigger the bug. 
According to the vulnerability test case, generate the test case of the target class #SmoothedValue#.
"""

message = f"""
# Code call path: {code_context}

# vulnerability test case: {vulnerable_test_case}

# target function: {target_function} 

There is a vulnerability in the createElement() method, and the vulnerability test case could trigger the bug. 
The Code call path include the function and code between the target function and vulnerable function.
According to the vulnerability test case, generate the test case of the target function.
"""

verifier_prompt = """
## Background:
  There are vulnerabilities in some Java third-party libraries. Developers may call these 
library functions as they work on the project, so when the project is put into use, Some user input can trigger these vulnerabilities and 
crash the program. Now we have collected a lot of projects that call vulnerable functions of third-party libraries, and detected the 
specific call locations of vulnerable library functions in the projects. 

## Information:
# Vulnerability Information: 
Spring Data Commons contain a property path parser vulnerability caused by unlimited resource allocation. An unauthenticated remote 
malicious user (or attacker) can issue requests against Spring Data REST endpoints or endpoints using property path parsing which can 
cause a denial of service (CPU and memory consumption).

# The test case that can trigger the vulnerability: 
@Test // DATACMNS-1285
public void rejectsTooLongPath() {
	String source = "foo.bar";
	for (int i = 0; i < 9; i++) {
		source = source + "." + source;
	}
	assertThat(source.split("\.").length, is(greaterThan(1000)));
	final String path = source;
	exception.expect(IllegalArgumentException.class);
	PropertyPath.from(path, Left.class);
}
private class Left {
        Right foo;
}
private class Right {
        Left bar;
}

# Signature of the target function: 
org.springframework.data.mongodb.core.convert.QueryMapper:forName(java.lang.String,java.lang.String)
# Code context of the target function:
protected static class MetadataBackedField extends Field {
	private final MongoPersistentEntity<?> entity;
	private PropertyPath forName(String path) {
		try {
			if (entity.getPersistentProperty(path) != null) {
				return PropertyPath.from(Pattern.quote(path), entity.getTypeInformation());
			}
			return PropertyPath.from(path, entity.getTypeInformation());
		} catch (PropertyReferenceException | InvalidPersistentPropertyPath e) {
			if (path.endsWith("_id")) {
				return forName(path.substring(0, path.length() - 3) + "id");
			}
			return null;
		}
	}
}

# Generated Test case for targer function:
@Test
public void testInvalidPathThrowingExceptions() {
    String invalidPath = "invalidPath";
    when(entity.getPersistentProperty(invalidPath)).thenReturn(null);
    when(entity.getTypeInformation()).thenReturn(mock(Class.class));

    // Simulate exception during PropertyPath.from call
    doThrow(PropertyReferenceException.class).when(entity).getTypeInformation();
    PropertyPath result = forName(invalidPath);
    assertNull(result);
}

## Your Task:
Your companion, the test case generation expert - TG have generated a unit test case for the target function that calls the above 
vulnerability library function. You need to take the vulnerability trigger information, the source code of the target function, and the test 
cases Etc information to judge whether the test case generated by TG is valid, if not, the TG is required to regenerate the test case. 
In the judgment process, you need to refine your logic at each step.
"""

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are an expert in java code understanding and detection. You need to generate test case for "
                                      "the target function that might trigger a bug"},
        {"role": "user", "content": message1}
    ],
    temperature=0.7
)

answer1 = response.choices[0].message.content
print(answer1)
