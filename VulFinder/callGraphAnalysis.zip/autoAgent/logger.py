import os
import logging

def setup_logger(name, log_dir='logs'):
    # 创建日志目录，如果不存在
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 创建一个logger对象
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # 设置最低的日志级别

    # 创建一个文件处理器，日志文件路径根据模块名称动态设置
    log_path = os.path.join(log_dir, f'{name}.log')
    file_handler = logging.FileHandler(log_path)
    file_handler.setLevel(logging.DEBUG)  # 设置文件处理器的级别为DEBUG

    # 创建一个日志格式器
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)  # 将格式器添加到文件处理器

    # 如果logger没有处理器，添加处理器
    if not logger.handlers:
        logger.addHandler(file_handler)

    return logger