import autogen

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]
bug_api = "tf.reshape"
bug_info = """
TensorFlow提供了函数 tf.reshape(tensor, shape, name=None)。其中，参数tensor为一个张量；参数shape指定目标形状，类型可以为list、tuple或tf.Tensor。
当参数shape的类型为list，且list的元素个数(列表长度)超过255时会触发漏洞。
以下为一个相关的漏洞触发程序的示例
```
import tensorflow as tf
tf.reshape(tensor=[[1]],shape=tf.constant([0 for i in range(255)], dtype=tf.int64))
```
"""

test_case_generator = autogen.AssistantAgent(
    name="generator",
    system_message=f"""
    你是一个乐于助人的代码检测助手,首先你要理解以下信息：
    {bug_info}
    给定一行代码，其中存在对TensorFlow漏洞函数{bug_api}的代码调用. 你要做的就是判断这行代码是否可以触发TensorFlow的函数的漏洞。
    若可以触发，给出一组这行代码中漏洞函数{bug_api}的变量值使得这行代码可以触发漏洞。
    若不能触发，则进行解释并返回TERMINATE。
    你需要等待用户输入代码行，不需要自己生成，每当你生成一组变量值之后，你需要等待用户的验证结果。
    若验证失败，根据用户返回的失败信息和相关的测试输入重新生成新的测试输入。
    若验证成功，则返回TERMINATE。
    
    请至少生成2组变量值，当然变量值用例的数量越多越好，尽可能覆盖所有情况
    注意，你生成的每一组变量值，都要严格根据目标代码行的的变量生成，下面是一个例子代码行：
    total = sum(a, b)
    其中当sum()函数为漏洞函数，且a值等大于10时会触发漏洞
    那么你生成的测试输入的格式应该是：
    变量组1：a=11,b=3
    测试用例2：a=20，b=10
    ...
    在触发漏洞的变量组生成后，将变量组用例交给user_proxy进行验证，如果user_proxy验证失败，那么你需要根据返回的失败信息和相关的变量组重新生成。
    若验证成功或无法生成新的变量组，则向user_proxy发送"停止"。
    """,
    llm_config={
        "cache_seed": 42,
        "config_list": config_list,
        "timeout": 1600,
    }

)
# test_case_verifier = autogen.UserProxyAgent(
#     name="verifier",
#     human_input_mode="NEVER",
#     system_message="""
#         你的职责是获取generator传来的测试用例，和user_proxy传入的代码，你需要将测试用例传入代码并运行，看是否会触发漏洞api，若触发失败，则对该测试用例进行标记。
#         若触发成功，则将当前测试用例返回给user_proxy，generator对一个待测代码生成的所有测试用例运行完毕之后，一齐将结果交给user_proxy。注意，请等待测试用例运行完成之后，再返回信息""",
#     llm_config={
#         "cache_seed": 42,
#         "config_list": config_list,
#         "timeout": 1600,
#     },
#     code_execution_config={"use_docker": False}
#
# )
user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    system_message=f"""
        你是一个乐于助人的代码检测助手,首先你要理解以下信息：
        {bug_info}
        你的任务是，从用户处获取调用代码行，交给generator，并接受generator返回的变量组用例。
        你需要将每一组变量的值依次填入调用代码行中的{bug_api}中，然后运行查看代码行在当前变量组是否能够成功触发api漏洞，
        如果经过运行发现有某组变量无法触发bug，则将这组变量以及相关的失败信息交给generator，
        并要求generator生成新的变量组，直到generator发送给你"停止"。
        此时你应该输出所有的有效变量组.
    """,
    human_input_mode="NEVER",
    code_execution_config={"use_docker": False}
)
# groupchat = autogen.GroupChat(
#     agents=[user_proxy, test_case_generator, test_case_verifier], messages=[])
# manager = autogen.GroupChatManager(
#     groupchat=groupchat,
#     llm_config={
#         "cache_seed": 42,
#         "config_list": config_list,
#         "timeout": 1600,
#     })

function = """
def mlm_sample_text(params, x, random_documents=False):
    seed = params.get('seed', None)
    ctx_len = params["n_ctx"]
    assert 'mlm_mask_id' in params, 'the key `mlm_mask_id` must be set on your config to do masked language model training, specifying the id of the reserved mask token'

    mask_id = params['mlm_mask_id']
    cls_token_id = params.get('mlm_cls_token_id', None)
    num_tokens = params.get('n_vocab', None)

    mask_ignore_ids = set(params.get('mlm_mask_ignore_ids', []))
    mask_ignore_ids.add(cls_token_id)

    mask_prob = params.get('mlm_mask_prob', 0.15)
    same_token_prob = params.get('mlm_same_token_prob', 0.10)
    random_token_prob = params.get('mlm_random_token_prob', 0.)

    seq_len = ctx_len if cls_token_id is None else (ctx_len - 1)

    if random_documents:
        s = tf.size(x)
        r = tf.random.uniform([], maxval=(s - seq_len), dtype=tf.dtypes.int32, seed=seed)
        r1 = tf.range(r, r + seq_len)
        r1 = tf.reshape(r1, [seq_len])
        features = tf.gather(x, r1)
    else:
        features = x[:seq_len]

    # add cls token id if specified by `mlm_cls_token_id`
    if cls_token_id is not None:
        features = tf.pad(features, [[1, 0]], constant_values=cls_token_id)

    features = tf.cast(features, dtype=tf.int32)
    shape = features.shape

    # determine which tokens are mask-able
    can_mask = tf.not_equal(features, 0)
    for ignore_id in mask_ignore_ids:
        can_mask &= tf.not_equal(features, ignore_id)

    # generate boolean mask for masking ids
    mask_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed), mask_prob)
    mask_mask &= can_mask

    # generate mask for actually replacing the tokens, for allowing a small number of tokens to stay the same
    replace_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed),
                           1 - same_token_prob)

    # randomly replace some tokens with random tokens before masking
    if random_token_prob > 0:
        random_token_mask = tf.less(tf.random.uniform(shape, minval=0., maxval=1., dtype=tf.float32, seed=seed),
                                    random_token_prob)
        random_tokens = tf.random.uniform(shape, minval=1, maxval=num_tokens, dtype=tf.dtypes.int32, seed=seed)

        # make sure random tokens do not include illegal token ids specified by `mlm_mask_ignore_ids`
        random_can_mask = tf.not_equal(random_tokens, 0)
        for ignore_id in mask_ignore_ids:
            random_can_mask &= tf.not_equal(random_tokens, ignore_id)

        features = tf.where(random_token_mask & random_can_mask, random_tokens, features)

    # mask the tokens
    mask_tokens = tf.ones(shape, dtype=tf.int32) * mask_id
    masked_features = tf.where(mask_mask & replace_mask, mask_tokens, features)

    # labels will be set to 0 for all non-masked tokens
    labels = tf.where(mask_mask, tf.zeros(shape, dtype=tf.int32), features)

    masked_features, labels = map(lambda t: tf.reshape(t, [ctx_len]), (masked_features, labels))
    return masked_features, labels
"""
call_line = """
x = tf.reshape(x, feature_shape)
"""

line_explain = """, 其中, 函数to_integer_list用于将某种数据结构（如字符串、列表或其他可迭代对象）转换为整数列表"""


# """
# output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
# """


# """
# context_layer = tf.reshape(
#         context_layer,
#         [batch_size, from_seq_length, num_attention_heads * size_per_head])
# """



message = f"""
代码行 {call_line} 存在对 {bug_api} 函数的调用，请推断出可以这行代码可以触发漏洞的一组变量值，变量名要求与当前代码行一致。
若不存在可以触发漏洞的变量组，则无需生成变量组，并提供解释。
描述性文字请用中文进行回答, 如果某一个变量设置成任何内容都不会影响漏洞触发，那么你返回的测试输入中的该参数应该固定不变，并指明类型。
若某些变量不影响漏洞触发，那么在文末需要进行解释。
"""
user_proxy.initiate_chat(test_case_generator, message=message, max_turns=12)
