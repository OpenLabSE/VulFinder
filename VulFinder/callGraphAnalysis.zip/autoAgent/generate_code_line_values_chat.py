from openai import OpenAI
import os
import logger
import pandas as pd

# 设置日志记录器
logger = logger.setup_logger('generate_code_line_values_chat')

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'   # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")


bug_info0 = """
TensorFlow provides a function called tf.reshape(tensor, shape, name=None). Where the parameter tensor is a tensor; The shape parameter 
specifies the target shape, which can be a list, tuple, or tf.Tensor.
The vulnerability is triggered when the shape parameter is a list and the length of the list exceeds 255.
Here is an example of a related vulnerability trigger:
```
import tensorflow as tf
tf.reshape(tensor=[[1]],shape=tf.constant([0 for i in range(255)], dtype=tf.int64))
```
"""

call_line0 = """x = tf.reshape(x, feature_shape)"""
bug_api0 = "tf.reshape"


bug_info1 = """
"tf.range would result in crashes due to overflows if the start or end point are too large.
Here is an example of a related vulnerability trigger:
```
import tensorflow as tf
tf.range(start=-1e+38, limit=1)
```"
"""
bug_api1 = """tf.range()"""
call_line1 = """r1 = tf.range(start=r, limit=r + params["n_ctx"])"""

target_code_line_gpt_neo = pd.read_excel('../data/target_code_line.xlsx', sheet_name='gpt-neo')
target_code_line_bert = pd.read_excel('../data/target_code_line.xlsx', sheet_name='bert')
target_code_line_albert = pd.read_excel('../data/target_code_line.xlsx', sheet_name='albert')
target_code_line_electra = pd.read_excel('../data/target_code_line.xlsx', sheet_name='electra')

count = 0
for index, row in target_code_line_gpt_neo.iterrows():
    count += 1
    if count <= 10:
        continue
    if count > 80:
        break
    call_line = row['call_line']
    bug_api = row['bug_api']
    bug_info = row['bug_info']

    message = f"""
    ### Vulnerability Information:{bug_info}
    
    ### Target Code Line:{call_line}
    
    ### Your Task
    Line {call_line} contains a call to the {bug_api} API. Infer a set of variable values that can trigger the vulnerability for this 
    code line. The variable name needs to be the same as the current line of code. 
    
    ###Example 1:
    For the code: "x = tf.pow(tf.constant(all_unique_ids, shape=[num_examples], dtype=tf.int32),name), ",generate variable values that can trigger the bug.
    Analysis:this code contain 3 different variables:all_unique_ids,num_examples,name. But only two of them serve as the parameters
    of the vulnerability function--tf.constant.Therefore,you just need to generate test cases for which involved(all_unique_ids,num_examples)
    The format of the test case should be: 
            Test case 1:parameter1=xxx,parameter2=xxx
            Test case 2:parameter1=xxx,parameter2=xxx
    However, according to the Vulnerability Information, only when the parameter value is string and the parameter dtype is tf.float16 ,can function tf.constant trigger vulnerability.
    so the code:"x = tf.pow(tf.constant(all_unique_ids, shape=[num_examples], dtype=tf.int32),name), " has no vaild test case which trigger vulnerability.
    
    ###Example 2: 
    For the code: " label_ids = tf.reshape(label_ids, [-1]) ", generate variable values that can trigger the bug. 
    Bug API info: "TensorFlow provides a function called tf.reshape(tensor, shape, name=None). Where the parameter tensor is a tensor; 
    The shape parameter specifies the target shape, which can be a list, tuple, or tf.Tensor. The vulnerability is triggered when the 
    shape parameter is a list and the length of the list exceeds 255. 
    For example, line 'tf.reshape(tensor=[[1]],shape=tf.constant([0 for i in range(255)], dtype=tf.int64))' can trigger the bug." 
    Analysis: This line calls tf.reshape, but with the shape parameter fixed to [-1]. According to the bug, triggering this 
    vulnerability requires the shape parameter to be a list of length over 256. Therefore, there is no way to generate a value for this 
    line of code that would trigger the bug. """

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert in code understanding and detection."},
            {"role": "user", "content": message}
        ],
        temperature=0.7
    )

    answer1 = response.choices[0].message.content
    print(answer1)
    print('-------------------------------------------------------------------------------------------\n')
    logger.info(f"Prompt: {message}")
    logger.info(f"Answer:\n {answer1}")