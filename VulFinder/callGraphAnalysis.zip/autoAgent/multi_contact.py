# coding=utf-8
# @Time : 2024/5/25 10:19
# @Author : RoseLee
# @File : multi_contact
# @Project : agent-study
import json
import os

import chromadb

import autogen
from autogen import AssistantAgent, UserProxyAgent

# Accepted file formats for that can be stored in
# a vector database instance

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi", "api_type": "openai"},
]

assert len(config_list) > 0
print("models to use: ", [config_list[i]["model"] for i in range(len(config_list))])

assistant = AssistantAgent(
    name="assistant",
    system_message="You're a master python tester. Your task is to generate test cases for the function that might trigger the vulnerability."
                   "In order to make the generated test cases usable, test user will provide information about the vulnerabilities and"
                   "feedback on the effect of the generated test cases. If no effective feedback is forthcoming, end the conversation.",
    human_input_mode="NEVER",
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    },
)

ragproxyagent = UserProxyAgent(
    name="ragproxyagent",
    system_message="You're a python test user. Your task is to give the master python tester information about the target function"
                   "and the detail of vulnerability. In order to improve the coverage and effectiveness of test cases, you need to "
                   "verify that the test case has the correct input parameters, triggers the relevant vulnerabilities, and so on. "
                   "If there are problems, report them to the python tester. If there are no questions, end the conversation.",
    code_execution_config=False,
    human_input_mode="NEVER",
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    },
)

message = """
<Target Function:>
import tensorflow as tf
def embedding_lookup(input_ids, vocab_size, embedding_size=128, initializer_range=0.02, word_embedding_name="word_embeddings", use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
  return (output, embedding_table)

<Vulnerability Information:>
tf.reshape(tensor, shape, name=None)
If the the length of `shape` large than 250, it will trigger a denial of service via CHECK-failure (assertion failure).
"""

result = ragproxyagent.initiate_chat(
    assistant,
    message=message,
    max_turns=2
)
