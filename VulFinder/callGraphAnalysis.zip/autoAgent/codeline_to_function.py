from openai import OpenAI
import os
import logger

# 设置日志记录器
logger = logger.setup_logger('codeline_to_function')

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'   # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")


bug_info = """
TensorFlow provides a function called tf.reshape(tensor, shape, name=None). Where the parameter tensor is a tensor; The shape parameter 
specifies the target shape, which can be a list, tuple, or tf.Tensor.
The vulnerability is triggered when the shape parameter is a list and the length of the list exceeds 255.
Here is an example of a related vulnerability trigger:
```
import tensorflow as tf
tf.reshape(tensor=[[1]],shape=tf.constant([0 for i in range(255)], dtype=tf.int64))
```
"""

call_line = """x = tf.reshape(x, feature_shape)"""
bug_api = "tf.reshape"



message = f"""
### Vulnerability Information:{bug_info}

### Target Code Line:{call_line}

### Your Task
Line {call_line} contains a call to the {bug_api} function. Infer a set of variable values that can trigger the vulnerability for this 
code line. The variable name needs to be the same as the current line of code. 
"""


response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are an expert in code understanding and detection."},
        {"role": "user", "content": message}
    ],
    temperature=0.7
)

answer1 = response.choices[0].message.content
print(answer1)
logger.info(f"Prompt: {message}")
logger.info(f"Answer:\n {answer1}")


function_name = """embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False)"""
function_params = """input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False"""
function_code = """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""


call_line = """output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])"""

code_line_values = """[1 for i in range(256)]"""
code_line_params = """input_shape"""

assign_statements = """
input_ids = tf.expand_dims(input_ids, axis=[-1])
input_shape = get_shape_list(input_ids)
"""

code_line_info = answer1


message1 = f"""
### Target Function Signature:
{function_name}

### Target Function Code:
{function_code}

### Target Code Line:
{call_line}

### Target Code line info:
{code_line_info}

### Internal Variables Passing within Target Function:
{assign_statements}

### Example:
For example function:
def sum(a,b):
        x = a + b
        return x
target line is: x = a + b
and the variable in the code line is x=10
Your output should be:
Target Function inputs 1: a = 1, b = 9
Target Function inputs 2: a = -1, b = 11

### Your Task:
Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
values at the Target Code Line is consistent with the default variable values. 
The format of the output is: 
Target function input values 1: param1 = xxx, param2 =.. , 
Target function input values 2: param1 = xxx, param2 =.. , 
"""

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are an expert in code understanding and detection."},
        {"role": "user", "content": message},
        {"role": "assistant", "content": f"{answer1}"},
        {"role": "user", "content": message1}
    ],
    temperature=0.7
)

answer2 = response.choices[0].message.content
print(answer2)
logger.info(f"Prompt: {message1}")
logger.info(f"Answer:\n {answer2}")

