from openai import OpenAI
import os
import logger
import pandas as pd

# 设置日志记录器
logger = logger.setup_logger('generate_function_inputs_chat2')

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'  # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")

function_name2 = """def model_fn(features, labels, mode, params)"""

function_code2 = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""

call_line2 = """ x = tf.reshape(x, feature_shape.to_integer_list)"""

code_line_params2 = """feature_shape=[0 for i in range(256)]"""

assign_statements_context2 = """
features_dict = {"inputs": features, "labels": labels}
sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}
params = add_mode_to_params(params, mode)
batch_size = get_batch_size(params)
batch_dim = mtf.Dimension("batch", batch_size)
batch_dims = [batch_dim]
feature_length = sequence_length_dict["inputs"]
length_dim = mtf.Dimension("sequence", feature_length)
feature_shape = mtf.Shape(batch_dims + [length_dim])
x = tf.reshape(x, feature_shape.to_integer_list)
"""

message2 = f"""
    ### Target Function Signature:
    {function_name2}

    ### Target Function Code: {function_code2}

    ### Target Code Line:
    {call_line2}
    
    ### Internal Variables Passing within Target Function: {assign_statements_context2}
    
    ### Processing steps: 
    1.Locate the target line in the target function. 
    2.Start at the target line and work backwards through the code of 
    the target function. According to the value of the variable in the target function, the information of the variable in the code before 
    the target code line is gradually deduced. Finally, the input variables of the objective function are deduced.

    ### Your Task: Following the Processing steps, derive the target function inputs that makes the Target Code Line #{call_line2}# full of the 
    specified variable values #{code_line_params2}#. Note that due to code constraints, there may not exist adequate inputs to the target function, 
    and if so, please give the explanation about the code constraints. 
    The output format of the target function inputs should be: 
    Target function input values 1: param1 = xxx, param2 =.. , 
    Target function input values 2: param1 = xxx, param2 =.. , 
    """

# response2 = client.chat.completions.create(
#         model="gpt-3.5-turbo",
#         messages=[
#             {"role": "system", "content": "You are an expert in code understanding and detection. You need to generate input for the "
#                                           "function that might trigger a bug in the target function based on the information you're "
#                                           "provided."},
#             {"role": "user", "content": message2}
#         ],
#         temperature=0.7
#     )
#
# answer2 = response2.choices[0].message.content
# print(answer2)
# logger.info(f"Prompt: {message2}")
# logger.info(f"Answer:\n {answer2}")
# print('==========================================================================================================')

target_function_gpt_neo = pd.read_excel('../data/target_function_info1.xlsx', sheet_name='Sheet1')

count = 0
for index, row in target_function_gpt_neo.iterrows():
    count += 1
    if count <= 13:
        continue
    if count > 14:
        break
    function_name = row['function_name']
    function_params = row['function_params']
    function_code = row['function_code']
    call_line = row['call_line']
    code_line_params = row['code_line_params']
    assign_statements = row['assign_statements']

    related_function = """
    ### Related function info in target function:
    def get_shape_list(tensor, expected_rank=None, name=None):
      '''
      Returns a list of the shape of tensor, preferring static dimensions.
      '''
      if name is None:
        name = tensor.name
      if expected_rank is not None:
        #Raises an exception if the tensor rank is not of the expected rank.
        assert_rank(tensor, expected_rank, name)
    
      shape = tensor.shape.as_list()
      non_static_indexes = []
      for (index, dim) in enumerate(shape):
        if dim is None:
          non_static_indexes.append(index)
      if not non_static_indexes:
        return shape
      dyn_shape = tf.shape(tensor)
      for index in non_static_indexes:
        shape[index] = dyn_shape[index]
      return shape
    """
    internal_pass_info = """
      ### Key Variables Passing within Target Function:
      input_shape = get_shape_list(input_tensor, expected_rank=3)
      batch_size = input_shape[0]
      seq_length = input_shape[1]
      width = input_shape[2]
      output = input_tensor
      if use_position_embeddings:
          num_dims = len(output.shape.as_list())
          position_broadcast_shape = []
          for _ in range(num_dims - 2):
            position_broadcast_shape.append(1)
          position_broadcast_shape.extend([seq_length, width])
          position_embeddings = tf.reshape(position_embeddings, position_broadcast_shape)
    """
    # ### Internal Variables Passing within Target Function: {assign_statements_context2}

    message1 = f"""
    ### Target Function Signature:
    {function_name}
    
    ### Target Function Code: {function_code}
    
    ### Target Code Line:
    {call_line}
    
    ### Example:
    For example function:
    def sum(a,b):
            x = a + b
            return x
    target line is: x = a + b
    and the variable in the code line is x=10
    Your output should be:
    Target Function inputs 1: a = 1, b = 9
    Target Function inputs 2: a = -1, b = 11
    
    ### Processing steps: 
    1.Locate the target line in the target function. 
    2.Start at the target line and work backwards through the code of 
    the target function. According to the value of the variable in the target function, the information of the variable in the code before 
    the target code line is gradually deduced. Finally, the input variables of the objective function are deduced. 
    
    ### Your Task: Following the Processing steps, derive the target function inputs that makes the Target Code Line #{call_line}# full of the 
    specified variable values #{code_line_params}#. 
    
    Note that: 
    1) Due to code constraints, there may not exist adequate inputs to the target function,
    and if so, please give the explanation about the code constraints. 
    2) You don't have to worry about things like memory overflow and computation time.
    3) Related function info in target function is provided.
    4) The output format of the target function inputs should be:
      Target function input values 1: param1 = xxx, param2 =.. ,
      Target function input values 2: param1 = xxx, param2 =.. ,
    """

    # response = client.chat.completions.create(
    #     model="gpt-3.5-turbo",
    #     messages=[
    #         {"role": "system", "content": "You are an expert in code understanding and detection. You need to generate input for the "
    #                                       "function that might trigger a bug in the target function based on the information you're "
    #                                       "provided."},
    #         {"role": "user", "content": message1}
    #     ],
    #     temperature=0.7
    # )

    # answer1 = response.choices[0].message.content
    # print(f"-----target code line: {code_line_params}")
    # print(f"-----function code: {function_code}")
    # print('----------------------------------------------')
    # print(answer1)
    # logger.info(f"Prompt: {message1}")
    # logger.info(f"Answer:\n {answer1} \n"
    #             f"====================================================================================")
    # print('==========================================================================================================')

    '''
    Key Variables Passing within Target Function expose variable passing information in the target function that relates to key variables in the target line
        In addition, the Related function contains information about external functions called in the target function.'''

    message2_1 = f"""
    ### Target Function Signature:
    {function_name}
    
    ### Target Function Code: {function_code}
    
    ### Target Code Line:
    {call_line}
    
    ### Your Task: Locate the target line in the target function. Then, starting from the first line of the target function, 
    explain each code line until the target code {call_line} behavior is reached
    """

    response2_1 = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert in code understanding and detection."},
            {"role": "user", "content": message2_1}
        ],
        temperature=0.7
    )
    answer2_1 = response2_1.choices[0].message.content
    print(f"-----target code line: {call_line}")
    print(f"-----function code: {function_code}")
    print(answer2_1)
    logger.info(f"Prompt: {message2_1}")
    logger.info(f"Answer:\n {answer2_1}")
    print('--------------------------------------------------------------------------------\n')

    message2_2 = f"""
    ### Target Function Signature:
    {function_name}
    
    ### Target Function Code: {function_code}
    
    ### Target Code Line:
    {call_line}
    {related_function}
    
    ### Example:
    For example function:
    def sum(a,b):
            x = a + b
            return x
    target line is: x = a + b
    and the variable in the code line is x=10
    Your output should be:
    Target Function inputs 1: a = 1, b = 9
    Target Function inputs 2: a = -1, b = 11
    
    ### Your Task:
    1.Start at the target line and work backwards through the code of the target function.
    2.According to the value of the variable in the target function, deduce the information of the variable in the code before
    the target code line. 
    3.Finally, derive the values of target function inputs {function_params} that makes the Target Code Line #{call_line}# full of the
    specified variable values #{code_line_params}#.
     
    Note that: 
    1) Due to code constraints, there may not exist adequate inputs to the target function,
    and if so, please give the explanation about the code constraints. 
    2) You don't have to worry about things like memory overflow and computation time.
    3) Related function info in target function is provided.
    4) The output format of the target function inputs should be:
      Target function input values 1: param1 = xxx, param2 =.. ,
      Target function input values 2: param1 = xxx, param2 =.. ,
    """

    response2_2 = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert in code understanding and detection. You need to generate input for "
                                          "the function that might trigger a bug in the target function based on the information"
                                          "you're provided. The test input will involve extreme cases, so you don't need to think about "
                                          "memory limitations or computational constraints"},
            {"role": "user", "content": message2_1},
            {"role": "assistant", "content": f"{answer2_1}"},
            {"role": "user", "content": message2_2}
        ],
        temperature=0.7
    )
    answer2_2 = response2_2.choices[0].message.content
    print(answer2_2)
    logger.info(f"Prompt: {message2_2}")
    logger.info(f"Answer:\n {answer2_1}")