# coding=utf-8
# @Time : 2024/7/5 10:39
# @Author : RoseLee
# @File : 函数级别测试用例生成
# @Project : agent-study
import autogen
import pandas as pd
config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]


def agentchat(assistant_prompt,verifier_prompt,message):

    assistant = autogen.AssistantAgent(
        name="assistant",
        system_message=assistant_prompt,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",

    )
    user_proxy = autogen.UserProxyAgent(
        name="user_proxy",
        human_input_mode="ALWAYS",
        code_execution_config={"use_docker": False},
        # is_termination_msg=True,

        max_consecutive_auto_reply=5
    )
    test_case_verifier = autogen.AssistantAgent(
        name="verifier",
        system_message=verifier_prompt,
        # is_termination_msg=True,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",
        max_consecutive_auto_reply=5
    )
    groupchat = autogen.GroupChat(
        agents=[user_proxy, test_case_verifier, assistant], messages=[])
    manager = autogen.GroupChatManager(
        groupchat=groupchat,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        })

    user_proxy.initiate_chat(manager, message=message, max_turns=2)


if __name__ == '__main__':
    df = pd.read_excel('code_info.xlsx',sheet_name='结果')
    for index,row in df.iterrows():
        function_name = row['function_name']
        function_params = row['function_params']
        function_code = row['function_code']
        call_line = row['call_line']
        code_line_values = row['code_line_values']
        code_line_params = row['code_line_params']
        assign_statements = row['assign_statements']
        other_info = '''
        autoregressive_sample_text_random_documents(params, x)函数中，对参数x使用了tf.size(x)，因此在使用过程中，测试用例中的x一定是一个tensor。
        '''
        print(f"当前代码行为：{call_line},所在函数名为：{function_name}")
        assistant_prompt = f'''
            You are an expert in generating test inputs.
            The Target Function {function_name} contains the  Target Code Line which will get error when the Key Parameter({code_line_params}) of the Target Code Line
        is passed the default value({code_line_values}).But we do not know that if exist a test cases which will trigger this vulnerability through the 
        Internal Variables Passing path within Target Function({assign_statements}).

        ### Your Task
            Now, Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
        If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
        values at the Target Code Line is consistent with the default variable values. 
        The format of the output is: 
        Target function input values 1: param1 = xxx, param2 =.. , 
        Target function input values 2: param1 = xxx, param2 =.. , 
        After generating test cases(if exists),You should take all the results to the verifier.

        Other relevant information will be given below
        ### Target Function Signature:
        {function_name}

        ### Target Function Code:
        {function_code}

        ### Target Code Line:
        {call_line}

        ### The Key Parameter:
        {code_line_params}

        ### Default Value of The Key Parameter
        {code_line_values}

        ### Internal Variables Passing within Target Function(the passing path from the function parameter to the key paramter of the target code line ):
        {assign_statements}
        
        ###Other Information
        {other_info}

        ### Example:
        For example function:
        def sum(a,b):
                x = a + b
                f(x)
                return x
        function name is sum(a,b)
        target code line is: f(x)
        The key parameter is x 
        default value of the key parameter is x=10
        internal variables passing within target function is :
            (a,b)
            x=a+b
            f(x)
        Your output should be:
        Target Function inputs 1: a = 1, b = 9
        Target Function inputs 2: a = -1, b = 11
        Target Function inputs 3: a = 2, b = 8
        etc.
        '''
        verifier_prompt = f'''
            You are a test case validation expert.
            The Target Function {function_name} contains the Target Code Line calling some tf functions(from tensorflow lib) which will get error when the 
        Key Parameter({code_line_params}) of the tf functions is passed the default value({code_line_values}).But we do not know that if exist a test cases
        of Target Function  will trigger this vulnerability through the Internal Variables Passing path within Target Function({assign_statements}).
        ### Your Task
            assistant will generate test cases to handle this question, and take the results to you. What you gotta do is verify if these test cases can
        trigger the vulnerability of the Target Code Line's tf function. After verifying you should tell the user_proxy all the test result.
        '''
        message = f''' 
                The Target Function {function_name} contains the Target Code Line calling some tf functions(from tensorflow lib) which will get error when the 
        Key Parameter({code_line_params}) of the tf functions is passed the default value({code_line_values}).But we do not know that if exist a test cases
        of Target Function  will trigger this vulnerability through the Internal Variables Passing path within Target Function({assign_statements}).
            Now, Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
        If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
        values at the Target Code Line is consistent with the default variable values. 
        if not trigger the vulnerability,just regenrate and test it until occupy valid test cases,if there is no possibility to generate valid test cases to 
        trigger vulnerability,just tell me the resulut.
        The format of the output is: 
        Target function input values 1: param1 = xxx, param2 =.. , 
        Target function input values 2: param1 = xxx, param2 =.. , 

        ### Internal Variables Passing within Target Function:
        {assign_statements}
        '''
        agentchat(assistant_prompt,verifier_prompt,message)
