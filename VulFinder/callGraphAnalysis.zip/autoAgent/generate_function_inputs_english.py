import autogen

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]

function_name0 = """model_fn(features, labels, mode, params)"""
function_params0 = """features, labels, mode, params"""
function_name = """embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False)"""
function_params = """input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False"""

function_code0 = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""
function_code = """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""
call_line0 = """x = tf.reshape(x, feature_shape.to_integer_list)"""
call_line = """output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])"""

code_line_values = """[1 for i in range(256)]"""
code_line_params = """input_shape"""

# line_explain = """, 其中, 函数to_integer_list用于将某种数据结构（如字符串、列表或其他可迭代对象）转换为整数列表"""

assign_statements = """
input_ids = tf.expand_dims(input_ids, axis=[-1])
input_shape = get_shape_list(input_ids)
"""

test_case_generator = autogen.AssistantAgent(
    name="generator",
    system_message=f""" You are an expert in code understanding and detection. 
    The user will provide information about the Target Function and the Target Code Line. Your task is to determine whether the value of 
    the variable in the Target Code Line is likely to be the default value provided by the user. If possible, provide the test inputs of 
    the Target Function that satisfies the variable's value. If this is not possible, please provide an explanation. After that, 
    the user will validate your output, and if the validation fails, you should generate new inputs based on the user's failure message. 
    If the verification is successful, TERMINATE is returned.
    """,
    llm_config={
        "cache_seed": 42,
        "config_list": config_list,
        "timeout": 1600,
    }
)

user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    system_message=f""" You are an expert in code detection. Your task is to understand the target function code provided by the user and 
    the preset variable values of the target code line, and accept the test input of the target function generated by the generator. 
    You need to verify if the variable information after executing the target function under the test input generated by the generator 
    is consistent with the preset variable value. If it is consistent, a success message is returned. If not, we return failure and 
    provide inconsistent variable values. """,
    human_input_mode="NEVER",
    code_execution_config={"use_docker": False}
)

message = f"""
### Example:
    For example function:
    def sum(a,b):
            x = a + b
            return x
    target line is: x = a + b
    and the variable in the code line is x=10
    Your output should be:
    Target Function inputs 1: a = 1, b = 9
    Target Function inputs 2: a = -1, b = 11

### Target Function Code:
{function_code}

### Target Function Signature:
{function_name}

### Target Code Line:
{call_line}

### Your Task:
Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
values at the Target Code Line is consistent with the default variable values. 
"""

user_proxy.initiate_chat(test_case_generator, message=message, max_turns=12)
