import autogen

config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]

function_name0 = """model_fn(features, labels, mode, params)"""
function_params0 = """features, labels, mode, params"""
function_name = """embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False)"""
function_params = """input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False"""

function_code0 = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""
function_code = """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""
call_line0 = """x = tf.reshape(x, feature_shape.to_integer_list)"""
call_line = """output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])"""

code_line_values = """[1 for i in range(256)]"""
code_line_params = """input_shape"""

line_explain = """, 其中, 函数to_integer_list用于将某种数据结构（如字符串、列表或其他可迭代对象）转换为整数列表"""

assign_statements = """
input_ids = tf.expand_dims(input_ids, axis=[-1])
input_shape = get_shape_list(input_ids)
"""

test_case_generator = autogen.AssistantAgent(
    name="generator",
    system_message=f"""
    你是一个乐于助人的代码检测助手,首先你要理解以下信息：
    给定目标函数: {function_name}，其输入变量为: {function_params}，函数中变量的传递关系为{assign_statements}
    目标函数的代码中包含了目标代码行。请判断目标代码行中变量{code_line_params}的值是否可能为{code_line_values}。
    若不可能，请提供相关的解释；若可能，请提供能满足该变量值的目标函数的输入。
    你需要等待用户输入目标代码行，不需要自己生成，每当你生成满足该变量值的目标函数的输入后，你需要等待用户的验证结果。
    若验证失败，根据用户返回的失败信息重新生成新的输入值。
    若验证成功，则返回TERMINATE。
    
    注意，生成的目标函数的输入需要为具体的变量值.
    例如，对于函数
    def sum(a,b):
        x = a + b
        return x
    目标代码行x = a + b中的预设变量值x=10
    那么你生成的测试输出的格式应该是：
    目标函数输入值1: a = 1, b = 9
    目标函数输入值2: a = -1, b = 11
    """,
    llm_config={
        "cache_seed": 42,
        "config_list": config_list,
        "timeout": 1600,
    }
)


user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    system_message=f"""
        你是一个乐于助人的代码检测助手,首先你要理解以下信息：
        给定目标函数: {function_name}
        以及目标代码行: {call_line}
        你的任务是，从用户处获取目标函数的代码片段，目标代码行以及目标代码行中的预设变量值，交给generator，并接受generator生成的目标函数的变量值。
        你需要验证目标函数在generator生成的的变量值下，执行到目标代码行后的变量信息是否与预设变量值一致。
        若一致，则返回成功信息; 若不一致，则返回失败，并提供不一致的变量值。
    """,
    human_input_mode="NEVER",
    code_execution_config={"use_docker": False}
)


message = f"""
{function_code}
以上为目标函数{function_name}的代码片段. 
目标函数的输入变量为 {function_params}
请判断目标代码行 {call_line} 中变量{code_line_params}的是否可能为预设变量值{code_line_params}。 若可能，请推断出目标函数的输入值，使得目标函数在执行到目标代码行后产生的变量信息与预设变量值一致。
若不可能，请提供解释说明。
"""

user_proxy.initiate_chat(test_case_generator, message=message, max_turns=12)
