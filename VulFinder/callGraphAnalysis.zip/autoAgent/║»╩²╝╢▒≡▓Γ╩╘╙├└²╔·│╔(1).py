# coding=utf-8
# @Time : 2024/7/5 10:39
# @Author : RoseLee
# @File : 函数级别测试用例生成
# @Project : agent-study
import autogen
import pandas as pd
config_list = [
    {"model": "gpt-3.5-turbo", "api_key": "sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi",
     "api_type": "openai"},
]




def agentchat(assistant_prompt,verifier_prompt,message):

    assistant = autogen.AssistantAgent(
        name="assistant",
        system_message=assistant_prompt,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",

    )
    user_proxy = autogen.UserProxyAgent(
        name="user_proxy",
        human_input_mode="ALWAYS",
        code_execution_config={"use_docker": False},
        # is_termination_msg=True,

        max_consecutive_auto_reply=5
    )
    test_case_verifier = autogen.AssistantAgent(
        name="verifier",
        system_message=verifier_prompt,
        # is_termination_msg=True,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        },
        human_input_mode="NEVER",
        max_consecutive_auto_reply=5
    )
    groupchat = autogen.GroupChat(
        agents=[user_proxy, test_case_verifier, assistant], messages=[])
    manager = autogen.GroupChatManager(
        groupchat=groupchat,
        llm_config={
            "cache_seed": 42,
            "config_list": config_list,
            "timeout": 1600,
        })

    user_proxy.initiate_chat(manager, message=message, max_turns=2)

if __name__ == '__main__':
    df = pd.read_excel('01_收集函数信息.xlsx',sheet_name='version2')
    for index,row in df.iterrows():
        function_name = row['function_name']
        function_params = row['function_params']
        function_code = row['function_code']
        call_line = row['call_line']
        code_line_values = row['code_line_values']
        code_line_params = row['code_line_params']
        assign_statements = row['assign_statements']
        other_info = '''
        autoregressive_sample_text_random_documents(params, x)函数中，对参数x使用了tf.size(x)，因此在使用过程中，测试用例中的x一定是一个tensor。
        
        '''
        print(f"当前代码行为：{call_line},所在函数名为：{function_name}")
        assistant_prompt = f'''
            You are an expert in generating test inputs.
            The Target Function {function_name} contains the Target Code Line which will get error when the Key Parameter({code_line_params})
        of the Target Code Line is passed the default value({code_line_values}).But we do not know that if exist a test cases
        of The Target Function which will trigger this vulnerability through the Internal Variables Passing path within Target 
        Function({assign_statements}).

        ### Your Task
            Now, Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default 
        value {code_line_values} by adjusting the values of Target Function Parameter:{function_params}, The Processing Procedure
        will be given below. If this is not possible, please provide an explanation; If possible, infer the input values(for the
        function parameters list) of the target function such that the variable values at the Target Code Line is consistent with
        the default variable values. 
        
        ### The Processing Procedure
            First,assigning Default Value of The Key Parameter to The Key Parameter. Second, analysing the Internal 
        Variables Passing within Target Function.Thrid, deducing the values of Target Function Parameters upward 
        based on the Internal Variables Passing within Target Function step by step,in the third step,each deduce
        needs to be made in the variables that have a direct relationship and requires an explanation.
        
        ### Example:
        For example function:
        def sum(a,b):
            c = a *2 +6
            d = b+3
            e = (d +6)/c
            x = e-c
            f(x)
            return x
        function name is sum(a,b)
        target function parameter is a and b.
        target code line is: f(x)
        The key parameter is x 
        default value of the key parameter is x=10
        internal variables passing within target function is :
            (a,b)
            c = a *2 +6
            d = b+3
            e = (d +6)/c
            x = e-c
            f(x)
            According The Processing Procedure,your analysis process should look like the following
            First,the key parameter x should be the default value 10.
            Second,The variables directly related to x are e,c. The variable c directly related to
        the a, e directly relatedto the d and c,d directly related to the b.Then a and b is the 
        parameters of this function('->' indicates value passing ).
            Thrid,each step and their explanation is :x should be 10 -> e-c should be 10 -> 
        (d+6)/c -c should be 10 -> ((b+3)+6)/c -c should be 10 ->((b+3)+6)/(a*2+6) -(a*2+6) should be 10,
        which means b = (2*a+6)*(16+2a)-9.
        In order for the variable x to have a value of 10, the parameter can be a = 1,b=153
        Your reply should be :Target function input values 1: a = 1, b=153
        
        ###The Format Of The Output is: 
        Target function input values 1: param1 = xxx, param2 =.. , 
        Target function input values 2: param1 = xxx, param2 =.. , 
        After generating test cases(if exists),You should take all the results to the verifier.

        Other relevant information will be given below
        ### Target Function Signature:
        {function_name}
        
        ### Target Function Parameters:
        {function_params}
        
        ### Target Function Code:
        {function_code}

        ### Target Code Line:
        {call_line}

        ### The Key Parameter:
        {code_line_params}

        ### Default Value of The Key Parameter
        {code_line_values}

        ### Internal Variables Passing within Target Function(the passing path from the function parameter to the key paramter of the target code line ):
        {assign_statements}
        


        
        '''
        ###Other Information
        # {other_info}


        verifier_prompt = f'''
            You are a test case validation expert.
            The Target Function {function_name} contains the Target Code Line calling some tf functions(from tensorflow lib) which will get error when the 
        Key Parameter({code_line_params}) of the tf functions is passed the default value({code_line_values}).But we do not know that if exist a test cases
        of Target Function  will trigger this vulnerability through the Internal Variables Passing path within Target Function({assign_statements}).
        ### Your Task
            assistant will generate test cases to handle this question, and take the results to you. What you gotta do is verify if these test cases can
        trigger the vulnerability of the Target Code Line's tf function. After verifying you should tell the user_proxy all the test result.
        ###Test Basis
        Test Basis is to judge when the input of the target function is the test cases,if the key parameter of the target code
        line could be the default value.
        '''
        message = f''' 
                The Target Function {function_name} contains the Target Code Line calling some tf functions(from tensorflow lib) which will get error when the 
        Key Parameter({code_line_params}) of the tf functions is passed the default value({code_line_values}).But we do not know that if exist a test cases
        of Target Function  will trigger this vulnerability through the Internal Variables Passing path within Target Function({assign_statements}).
            Now, Check whether the variable {code_line_params} in the Target Code Line {call_line} is likely to be the default value {code_line_values}. 
        If this is not possible, please provide an explanation; If possible, infer the input values of the target function such that the variable 
        values at the Target Code Line is consistent with the default variable values.
            You should let assisant generate test cases and let verifier to verify those test cases generated. Test basis
        is to judge when the input of the target function is the test cases,if the key parameter of the target code line 
        could be the default value.
            After your analysis , there is possible to generate vaild test cases but all the test cases you generate fail 
        in testing,just regenrate test cases according the information and test it until occupy valid test cases,if there 
        is no possibility to generate valid test cases to let the value of the key parameter to be the default value,just 
        tell me the result.
        
        ####The Format Of Test Cases Output: 
        Target function input values 1: param1 = xxx, param2 =.. , 
        Target function input values 2: param1 = xxx, param2 =.. , 

        ### Internal Variables Passing within Target Function:
        {assign_statements}
        
        ### The Processing Procedure
            First,assigning Default Value of The Key Parameter to The Key Parameter. Second, analysing the Internal 
        Variables Passing within Target Function.Thrid, deducing the values of Target Function Parameters upward 
        based on the Internal Variables Passing within Target Function step by step,in the third step,each deduce
        needs to be made in the variables that have a direct relationship and requires an explanation.
        
        ### Example:
        For example function:
        def sum(a,b):
            c = a *2 +6
            d = b+3
            e = (d +6)/c
            x = e-c
            f(x)
            return x
        function name is sum(a,b)
        target function parameter is a and b.
        target code line is: f(x)
        The key parameter is x 
        default value of the key parameter is x=10
        internal variables passing within target function is :
            (a,b)
            c = a *2 +6
            d = b+3
            e = (d +6)/c
            x = e-c
            f(x)
            According The Processing Procedure,your analysis process should look like the following
            First,the key parameter x should be the default value 10.
            Second,The variables directly related to x are e,c. The variable c directly related to
        the a, e directly relatedto the d and c,d directly related to the b.Then a and b is the 
        parameters of this function('->' indicates value passing ).
            Thrid,each step and their explanation is :x should be 10 -> e-c should be 10 -> 
        (d+6)/c -c should be 10 -> ((b+3)+6)/c -c should be 10 ->((b+3)+6)/(a*2+6) -(a*2+6) should be 10,
        which means b = (2*a+6)*(16+2a)-9.
        In order for the variable x to have a value of 10, the parameter can be a = 1,b=153
        Your reply should be :Target function input values 1: a = 1, b=153
        ###Attention
            If all the test cases you generated all not 
        '''
        agentchat(assistant_prompt,verifier_prompt,message)
