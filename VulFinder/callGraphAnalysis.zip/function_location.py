import ast


# 分析代码行所在的函数
def get_function_at_line(file_path, line_number):
    with open(file_path, 'r', encoding='utf-8') as file:
        source_code = file.read()

    # 解析源代码为AST
    tree = ast.parse(source_code, filename=file_path)

    # 递归遍历AST节点
    def traverse_node(node):
        for child_node in ast.iter_child_nodes(node):
            result = traverse_node(child_node)
            if result:
                return result
        if isinstance(node, ast.FunctionDef) and node.lineno <= line_number <= node.end_lineno:
            return node.name
        return None

    return traverse_node(tree)


if __name__ == '__main__':
    lines = [634, 732, 738]
    for lineno in lines:
        print(get_function_at_line('data/input/modeling.py', lineno))
