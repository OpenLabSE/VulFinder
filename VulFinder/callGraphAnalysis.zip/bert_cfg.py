import ast
import pydot
import metacircularinterpreter
import textwrap as tw


class Graphics:
    def display_dot(self, dotsrc):
        raise NotImplemented


class CLIGraphics(Graphics):
    def __init__(self):
        global graphviz
        import graphviz
        globals()['graphviz'] = graphviz
        self.i = 0

    def display_dot(self, dotsrc):
        graphviz.Source(dotsrc).render(format='png', outfile='data/%s.png' % self.i)
        self.i += 1


def get_color(p, c):
    color = 'black'
    while not p.annotation():
        if p.label == 'if:True':
            return 'blue'
        elif p.label == 'if:False':
            return 'red'
        p = p.parents[0]
    return color


# The *peripheries* determines the number of border lines. Start and stop gets double borders.

def get_peripheries(p):
    annot = p.annotation()
    if annot in {'<start>', '<stop>'}:
        return '2'
    if annot.startswith('<define>') or annot.startswith('<exit>'):
        return '2'
    return '1'


# The *shape* determines the kind of node. A diamond is a conditional, and start and stop are ovals.

def get_shape(p):
    annot = p.annotation()
    if annot in {'<start>', '<stop>'}:
        return 'oval'
    if annot.startswith('<define>') or annot.startswith('<exit>'):
        return 'oval'

    if annot.startswith('if:'):
        return 'diamond'
    else:
        return 'rectangle'


# The `to_graph()` function produces a graph from the nodes in the registry.

def to_graph(my_nodes, arcs=[], comment='',
             get_shape=lambda n: 'rectangle',
             get_peripheries=lambda n: '1', get_color=lambda p, c: 'black'):
    G = pydot.Dot(comment, graph_type="digraph")
    for nid, cnode in my_nodes:
        if not cnode.annotation():
            continue
        sn = cnode.annotation()
        G.add_node(pydot.Node(cnode.name(),
                              label=sn,
                              shape=get_shape(cnode),
                              peripheries=get_peripheries(cnode)))
        for pn in cnode.parents:
            gp = pn.get_gparent_id()
            color = get_color(pn, cnode)
            G.add_edge(pydot.Edge(gp, str(cnode.rid), color=color))
    return G


# ### The CFGNode
#
# The control flow graph is a graph, and hence we need a data structue for the *node*. We need to store the parents
# of this node, the children of this node, and register itself in the registery.

class GraphState:
    def __init__(self):
        self.counter = 0
        self.registry = {}
        self.stack = []


class CFGNode:
    counter = 0
    registry = {}
    stack = []

    def __init__(self, parents=[], ast=None, label=None, annot=None, state=None):
        self.parents = parents
        self.calls = []
        self.children = []
        self.ast_node = ast
        self.label = label
        self.annot = annot
        self.rid = state.counter
        state.registry[self.rid] = self
        state.counter += 1
        self.state = state


# Given that it is a directed graph node, we need the ability to add parents and children.

class CFGNode(CFGNode):
    def add_child(self, c):
        if c not in self.children:
            self.children.append(c)

    def set_parents(self, p):
        self.parents = p

    def add_parent(self, p):
        if p not in self.parents:
            self.parents.append(p)

    def add_parents(self, ps):
        for p in ps:
            self.add_parent(p)

    def add_calls(self, func):
        mid = None
        if hasattr(func, 'id'):  # ast.Name
            mid = func.id
        else:  # ast.Attribute
            mid = func.value.id
        self.calls.append(mid)


# A few convenience methods to make our life simpler.

class CFGNode(CFGNode):
    def __eq__(self, other):
        return self.rid == other.rid

    def __neq__(self, other):
        return self.rid != other.rid

    def lineno(self):
        if hasattr(self.ast_node, 'lineno'):
            if (isinstance(self.ast_node, ast.AnnAssign)):
                if self.ast_node.target.id == 'exit':
                    return -self.ast_node.lineno
            return self.ast_node.lineno
        # should we return the parent line numbers instead?
        return 0

    def name(self):
        return str(self.rid)

    def expr(self):
        return self.source()

    def __str__(self):
        return "id:%d line[%d] parents: %s : %s" % \
               (self.rid, self.lineno(),
                str([p.rid for p in self.parents]), self.source())

    def __repr__(self):
        return str(self)

    def source(self):
        if self.ast_node is None: return ''
        return ast.unparse(self.ast_node).strip()

    def annotation(self):
        if self.annot is not None:
            return self.annot
        if self.source() in {'start', 'stop'}:
            return "<%s>" % self.source()
        return self.source()

    def to_json(self):
        return {'id': self.rid, 'parents': [p.rid for p in self.parents],
                'children': [c.rid for c in self.children],
                'calls': self.calls, 'at': self.lineno(), 'ast': self.source()}

    def get_gparent_id(self):
        p = self.state.registry[self.rid]
        while not p.annotation():
            p = p.parents[0]
        return str(p.rid)


class PyCFGExtractor(metacircularinterpreter.PyMCInterpreter):
    def __init__(self):
        self.gstate = self.create_graphstate()
        self.founder = CFGNode(parents=[],
                               ast=ast.parse('start').body[0],
                               state=self.gstate)  # sentinel
        self.founder.ast_node.lineno = 0
        self.functions = {}
        self.functions_node = {}

    def create_graphstate(self):
        return GraphState()


class PyCFGExtractor(PyCFGExtractor):
    def walk(self, node, myparents):
        if node is None: return
        fname = "on_%s" % node.__class__.__name__.lower()
        if hasattr(self, fname):
            return getattr(self, fname)(node, myparents)
        raise SyntaxError('walk: Not Implemented in %s' % type(node))

# parse is just ast.parse
    def parse(self, src):
        return ast.parse(src)

    def eval(self, src):
        node = self.parse(src)
        nodes = self.walk(node, [self.founder])
        self.last_node = CFGNode(parents=nodes,
                                 ast=ast.parse('stop').body[0],
                                 state=self.gstate)
        ast.copy_location(self.last_node.ast_node, self.founder.ast_node)
        self.post_eval()

    def post_eval(self): ...  # to be overridden

    # The pass statement is trivial. It simply adds one more node.
    def on_pass(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, state=self.gstate)]
        return p

    # We next define the `Module`. A python module is composed of a sequence of statements,
    # and the graph is a linear path through these statements. That is, each time a statement
    # is executed, we make a link from it to the next statement.
    def on_module(self, node, myparents):
        p = myparents
        for n in node.body:
            p = self.walk(n, p)
        return p

    def on_str(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, annot='', state=self.gstate)]
        return p

    def on_num(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, annot='', state=self.gstate)]
        return p

    def on_constant(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, annot='', state=self.gstate)]
        return p

    def on_expr(self, node, myparents):
        p = self.walk(node.value, myparents)
        p = [CFGNode(parents=p, ast=node, state=self.gstate)]
        return p

    def on_unaryop(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, annot='', state=self.gstate)]
        return self.walk(node.operand, p)

    def on_binop(self, node, myparents):
        left = self.walk(node.left, myparents)
        right = self.walk(node.right, left)
        p = [CFGNode(parents=right, ast=node, annot='', state=self.gstate)]
        return p

    def on_compare(self, node, myparents):
        left = self.walk(node.left, myparents)
        right = self.walk(node.comparators[0], left)
        p = [CFGNode(parents=right, ast=node, annot='', state=self.gstate)]
        return p

    def on_assign(self, node, myparents):
        if len(node.targets) > 1: raise NotImplemented('Parallel assignments')
        p = [CFGNode(parents=myparents, ast=node, state=self.gstate)]
        p = self.walk(node.value, p)
        return p

    def on_name(self, node, myparents):
        p = [CFGNode(parents=myparents, ast=node, annot='', state=self.gstate)]
        return p

    # We now come to the control structures. For the `if` statement, we have two
    # parallel paths. We first evaluate the test expression, then add a new node
    # corresponding to the if statement, and provide the paths through the `if.body`
    # and `if.orelse`.
    def on_if(self, node, myparents):
        p = self.walk(node.test, myparents)
        test_node = [CFGNode(parents=myparents, ast=ast.parse(
            '_if: %s' % ast.unparse(node.test).strip()).body[0],
                             annot="if: %s" % ast.unparse(node.test).strip(),
                             state=self.gstate)]
        ast.copy_location(test_node[0].ast_node, node.test)
        g1 = test_node
        g_true = [CFGNode(parents=g1,
                          ast=ast.parse('_if: True').body[0],
                          label="if:True",
                          annot='',
                          state=self.gstate)]
        ast.copy_location(g_true[0].ast_node, node.test)
        g1 = g_true
        for n in node.body:
            g1 = self.walk(n, g1)
        g2 = test_node
        g_false = [CFGNode(parents=g2,
                           ast=ast.parse('_if: False').body[0],
                           label="if:False",
                           annot='',
                           state=self.gstate)]
        ast.copy_location(g_false[0].ast_node, node.test)
        g2 = g_false
        for n in node.orelse:
            g2 = self.walk(n, g2)
        return g1 + g2

    # #### While
    # The `while` statement is more complex than the `if` statement. For one,
    # we need to provide a way to evaluate the condition at the beginning of
    # each iteration.
    def on_while(self, node, myparents):
        loop_id = self.gstate.counter
        lbl1_node = CFGNode(parents=myparents,
                            ast=node,
                            label='loop_entry',
                            annot='%s: while' % loop_id,
                            state=self.gstate)
        p = self.walk(node.test, [lbl1_node])

        lbl2_node = CFGNode(parents=p, ast=node.test, label='while:test',
                            annot='if: %s' % ast.unparse(node.test).strip(), state=self.gstate)
        g_false = CFGNode(parents=[lbl2_node],
                          ast=None,
                          label="if:False",
                          annot='',
                          state=self.gstate)
        g_true = CFGNode(parents=[lbl2_node],
                         ast=None,
                         label="if:True",
                         annot='',
                         state=self.gstate)
        lbl1_node.exit_nodes = [g_false]

        p = [g_true]

        for n in node.body:
            p = self.walk(n, p)

        # the last node is the parent for the lb1 node.
        lbl1_node.add_parents(p)

        return lbl1_node.exit_nodes

    def on_break(self, node, myparents):
        parent = myparents[0]
        while parent.label != 'loop_entry':
            parent = parent.parents[0]

        assert hasattr(parent, 'exit_nodes')
        p = CFGNode(parents=myparents, ast=node, state=self.gstate)

        # make the break one of the parents of label node.
        parent.exit_nodes.append(p)

        # break doesnt have immediate children
        return []

    def on_continue(self, node, myparents):
        parent = myparents[0]
        while parent.label != 'loop_entry':
            parent = parent.parents[0]

        p = CFGNode(parents=myparents, ast=node, state=self.gstate)
        parent.add_parent(p)

        return []

    def on_call(self, node, myparents):
        p = myparents
        for a in node.args:
            p = self.walk(a, p)
        myparents[0].add_calls(node.func)
        p = [CFGNode(parents=p,
                     ast=node,
                     label='call',
                     annot='',
                     state=self.gstate)]
        return p

    def on_for(self, node, myparents):
        # node.target in node.iter: node.body
        loop_id = self.gstate.counter

        for_pre = CFGNode(parents=myparents,
                          ast=None,
                          label='for_pre',
                          annot='',
                          state=self.gstate)

        init_node = ast.parse('__iv_%d = iter(%s)' % (
            loop_id, ast.unparse(node.iter).strip())).body[0]
        p = self.walk(init_node, [for_pre])

        lbl1_node = CFGNode(parents=p,
                            ast=node,
                            label='loop_entry',
                            annot='%s: for' % loop_id,
                            state=self.gstate)
        _test_node = ast.parse(
            '__iv_%d.__length__hint__() > 0' % loop_id).body[0].value
        p = self.walk(_test_node, [lbl1_node])

        lbl2_node = CFGNode(parents=p,
                            ast=_test_node,
                            label='for:test',
                            annot='for: %s' % ast.unparse(_test_node).strip(),
                            state=self.gstate)
        g_false = CFGNode(parents=[lbl2_node],
                          ast=None,
                          label="if:False",
                          annot='', state=self.gstate)
        g_true = CFGNode(parents=[lbl2_node],
                         ast=None,
                         label="if:True",
                         annot='',
                         state=self.gstate)
        lbl1_node.exit_nodes = [g_false]

        p = [g_true]

        # now we evaluate the body, one at a time.
        for n in node.body:
            p = self.walk(n, p)

        # the test node is looped back at the end of processing.
        lbl1_node.add_parents(p)

        return lbl1_node.exit_nodes

    # #### FunctionDef
    # When defining a function, we should define the `return_nodes` for the
    # return statement to hook into. Further, we should also register our
    # functions.
    def on_functiondef(self, node, myparents):
        # name, args, body, decorator_list, returns
        fname = node.name
        args = node.args
        returns = node.returns
        enter_node = CFGNode(
            parents=[], ast=ast.parse('enter: %s(%s)' % (
                node.name, ', '.join([a.arg for a in node.args.args]))).body[0],
            annot='<define>: %s' % node.name, state=self.gstate
        )  # sentinel
        enter_node.calleelink = True
        ast.copy_location(enter_node.ast_node, node)

        exit_node = CFGNode(parents=[], ast=ast.parse('exit: %s(%s)' % (
            node.name, ', '.join([a.arg for a in node.args.args]))).body[0],
                            annot='<>: %s' % node.name, state=self.gstate
                            )  # sentinel
        enter_node.return_nodes = []  # sentinel

        p = [enter_node]
        for n in node.body:
            p = self.walk(n, p)

        for n in p:
            if n not in enter_node.return_nodes:
                enter_node.return_nodes.append(n)

        for n in enter_node.return_nodes:
            exit_node.add_parent(n)

        self.functions[fname] = [enter_node, exit_node]
        self.functions_node[enter_node.lineno()] = fname

        return myparents

    def on_return(self, node, myparents):
        parent = myparents[0]

        val_node = self.walk(node.value, myparents)
        # on return look back to the function definition.
        while not hasattr(parent, 'return_nodes'):
            parent = parent.parents[0]
        assert hasattr(parent, 'return_nodes')

        p = CFGNode(parents=val_node, ast=node, state=self.gstate)

        # make the break one of the parents of label node.
        parent.return_nodes.append(p)

        # return doesnt have immediate children
        return []

    # We just need few more functions to ensure that our arrows are linked up
    def post_eval(self):
        self.update_children()
        self.update_functions()
        self.link_functions()

    # First, we make sure that all the child nodes are linked to from the parents.
    def update_children(self):
        for nid, node in self.gstate.registry.items():
            for p in node.parents:
                p.add_child(node)

    # Next, we make sure that for any node (marked by its line number)
    def get_defining_function(self, node):
        if node.lineno() in self.functions_node:
            return self.functions_node[node.lineno()]
        if not node.parents:
            self.functions_node[node.lineno()] = ''
            return ''
        val = self.get_defining_function(node.parents[0])
        self.functions_node[node.lineno()] = val
        return val

    def update_functions(self):
        for nid, node in self.gstate.registry.items():
            _n = self.get_defining_function(node)

    def link_functions(self):
        for nid, node in self.gstate.registry.items():
            if not node.calls: continue
            for calls in node.calls:
                if not calls in self.functions: continue
                enter, exit = self.functions[calls]
                enter.add_parent(node)
                if node.children:
                    # # unlink the call statement
                    assert node.calllink > -1
                    node.calllink += 1
                    for i in node.children:
                        i.add_parent(exit)


# The usage is as below:
if __name__ == '__main__':
    graphics = CLIGraphics()
    gs = GraphState()
    start = CFGNode(parents=[], ast=ast.parse('start').body, state=gs)

    s = """\
    def embedding_lookup(input_ids, vocab_size, embedding_size=128, initializer_range=0.02, word_embedding_name="word_embeddings", use_one_hot_embeddings=False):
      if input_ids.shape.ndims == 2:
        input_ids = tf.expand_dims(input_ids, axis=[-1])
    
      embedding_table = tf.get_variable(name=word_embedding_name, shape=[vocab_size, embedding_size], initializer=create_initializer(initializer_range))
    
      flat_input_ids = tf.reshape(input_ids, [-1])
      if use_one_hot_embeddings:
        one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
        output = tf.matmul(one_hot_input_ids, embedding_table)
      else:
        output = tf.gather(embedding_table, flat_input_ids)
    
      input_shape = get_shape_list(input_ids)
      output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
      return (output, embedding_table)
        """
    cfge = PyCFGExtractor()
    cfge.eval(tw.dedent(s))
    g = to_graph(cfge.gstate.registry.items(),
                 get_color=get_color,
                 get_peripheries=get_peripheries,
                 get_shape=get_shape)
    graphics.display_dot(g.to_string())