from openai import OpenAI
import os

proxy_url = 'http://127.0.0.1'
proxy_port = '7890'  # 端口号修改自己的

os.environ['http_proxy'] = f'{proxy_url}:{proxy_port}'
os.environ['https_proxy'] = f'{proxy_url}:{proxy_port}'

client = OpenAI(api_key="sk-proj-tdKPJXXxpxcwCgdrrApST3BlbkFJDu7zRcV7MiPZwzX3lyVi")

vulnerable_test_case = """
from PIL import ImageColor

def test_color_too_long():
    color_too_long = "hsl(" + "1" * 100 + ")"
    with pytest.raises(ValueError):
        ImageColor.getrgb(color_too_long)
"""

target_function = """
import PIL
from PIL import Image
from PIL import ImageColor
from PIL import ImageDraw
from PIL import ImagePath

class DonRenderer(IdenticonRendererBase):
    MIDDLE_PATCH_SET = [0, 4, 8, 15]

    def decode(self, code):
        # decode the code
        middleType = self.MIDDLE_PATCH_SET[code & 0x03]
        middleInvert = (code >> 2) & 0x01
        cornerType = (code >> 3) & 0x0F
        cornerInvert = (code >> 7) & 0x01
        cornerTurn = (code >> 8) & 0x03
        sideType = (code >> 10) & 0x0F
        sideInvert = (code >> 14) & 0x01
        sideTurn = (code >> 15) & 0x03
        blue = (code >> 16) & 0x1F
        green = (code >> 21) & 0x1F
        red = (code >> 27) & 0x1F

        foreColor = (red << 3, green << 3, blue << 3)
        return (middleType, middleInvert, 0), \
               (cornerType, cornerInvert, cornerTurn), \
               (sideType, sideInvert, sideTurn), \
               foreColor, ImageColor.getrgb('white')

//code line #foreColor, ImageColor.getrgb('white')# call the ImageColor.getrgb, which may contains the vulnerability.
"""

vulnerability_description = """PIL is vulnerable to Regular Expression Denial of Service (ReDoS) if the ImageColor:getrgb function accept 
a long color str value like "hsl("" + "1" * 100 + ")". """

message1 = f"""
# vulnerability triggering test case: {vulnerable_test_case}

# target program:{target_function}

{vulnerability_description}
Based on the code context, determine whether the target program can trigger the vulnerability. Please give the result of #Yes or #Not first. 
Yes means it is able to trigger the vulnerability, while Not means target program is unlikely to trigger the vulnerability. 
"""

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are an expert in java code understanding and detection. You need to determine whether the "
                                      "target program is likely to trigger the vulnerability based on the vulnerability information and "
                                      "the vulnerability triggering test case"},
        {"role": "user", "content": message1}
    ],
    temperature=0.7
)

answer1 = response.choices[0].message.content
print(answer1)