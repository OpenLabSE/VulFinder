import ast

class VariableTracer(ast.NodeVisitor):
    def __init__(self, target_variable):
        self.target_variable = target_variable
        self.relevant_lines = set()
        self.variable_dependencies = {}
        self.input_parameters = set()

    def visit_FunctionDef(self, node):
        self.input_parameters = {arg.arg for arg in node.args.args}
        self.generic_visit(node)

    def visit_Assign(self, node):
        for target in node.targets:
            if isinstance(target, ast.Name):
                var_name = target.id
                if var_name not in self.variable_dependencies:
                    self.variable_dependencies[var_name] = []
                self.variable_dependencies[var_name].append((node.lineno, node.value))
                if var_name == self.target_variable:
                    self.relevant_lines.add(node.lineno)
                    self._trace_variable_dependencies(node.value)
            elif isinstance(target, ast.Subscript):
                self._trace_variable_dependencies(target.value)
        self.generic_visit(node)

    def _trace_variable_dependencies(self, node):
        stack = [(node, set())]
        while stack:
            current_node, visited = stack.pop()
            if isinstance(current_node, ast.Name):
                var_name = current_node.id
                if var_name in self.variable_dependencies:
                    for lineno, dependency_node in self.variable_dependencies[var_name]:
                        if lineno not in visited:
                            self.relevant_lines.add(lineno)
                            stack.append((dependency_node, visited | {lineno}))
                elif var_name in self.input_parameters:
                    pass  # Input parameters are the end of the dependency chain
            elif isinstance(current_node, ast.BinOp):
                stack.append((current_node.left, visited))
                stack.append((current_node.right, visited))
            elif isinstance(current_node, ast.Call):
                for arg in current_node.args:
                    stack.append((arg, visited))
            elif isinstance(current_node, ast.Subscript):
                stack.append((current_node.value, visited))
                stack.append((current_node.slice, visited))
            elif isinstance(current_node, ast.List):
                for element in current_node.elts:
                    stack.append((element, visited))

    def get_relevant_lines(self):
        return sorted(self.relevant_lines)


def extract_relevant_code(func_code, target_variable):
    tree = ast.parse(func_code)
    tracer = VariableTracer(target_variable)
    tracer.visit(tree)
    relevant_lines = tracer.get_relevant_lines()

    code_lines = func_code.split('\n')
    relevant_code = [code_lines[i - 1] for i in relevant_lines]

    return relevant_code

# 示例函数文本
func_text = """
def model_fn(features, labels, mode, params):
    # Get global step
    global_step = tf.train.get_global_step()

    # Construct mtf graph + mesh from params
    graph = mtf.Graph()
    mesh_shape = mtf.convert_to_shape(params["mesh_shape"])
    layout_rules = mtf.convert_to_layout_rules(params["layout"])

    # Mesh setup
    if params["use_tpu"]:
        var_placer, mesh_impl = simd_mesh_setup(params, mesh_shape, layout_rules)
    else:
        var_placer = None
        gpu_ids = params["gpu_ids"]
        mesh_impl = mtf.placement_mesh_impl.PlacementMeshImpl(
            mesh_shape, layout_rules, gpu_ids)

    # Trainable variable precision
    # Store to checkpoints in master type, train in slice type, compute in activation type
    if params["precision"] == "bfloat16":
        variable_dtype = mtf.VariableDType(master_dtype=tf.bfloat16, slice_dtype=tf.float32,
                                           activation_dtype=tf.bfloat16)
    else:
        variable_dtype = mtf.VariableDType(master_dtype=tf.float32, slice_dtype=tf.float32, activation_dtype=tf.float32)

    # Build mtf mesh object
    mesh = mtf.Mesh(graph, "my_mesh", var_placer)

    # Build mtf_features & seq length dict for getting number of microbatches
    # We need to pack inputs into a dict to pass into serialize_training_step
    features_dict = {"inputs": features, "labels": labels}
    sequence_length_dict = {"inputs": params["n_ctx"], "labels": params["n_ctx"]}

    params = add_mode_to_params(params, mode)
    batch_size = get_batch_size(params)

    batch_dim = mtf.Dimension("batch", batch_size)
    batch_dims = [batch_dim]
    feature_length = sequence_length_dict["inputs"]
    length_dim = mtf.Dimension("sequence", feature_length)

    mtf_features = {}
    for key, x in features_dict.items():
        if x is not None:
            feature_shape = mtf.Shape(batch_dims + [length_dim])
            if type(features_dict[key]) == dict:
                features_dict[key] = features_dict[key]["feature"]
            x = tf.cast(features_dict[key], tf.int32)
            x = tf.reshape(x, feature_shape.to_integer_list)
"""
func_text2= """
def embedding_lookup(input_ids,
                     vocab_size,
                     embedding_size=128,
                     initializer_range=0.02,
                     word_embedding_name="word_embeddings",
                     use_one_hot_embeddings=False):
  if input_ids.shape.ndims == 2:
    input_ids = tf.expand_dims(input_ids, axis=[-1])

  embedding_table = tf.get_variable(
      name=word_embedding_name,
      shape=[vocab_size, embedding_size],
      initializer=create_initializer(initializer_range))

  flat_input_ids = tf.reshape(input_ids, [-1])
  if use_one_hot_embeddings:
    one_hot_input_ids = tf.one_hot(flat_input_ids, depth=vocab_size)
    output = tf.matmul(one_hot_input_ids, embedding_table)
  else:
    output = tf.gather(embedding_table, flat_input_ids)

  input_shape = get_shape_list(input_ids)

  output = tf.reshape(output, input_shape[0:-1] + [input_shape[-1] * embedding_size])
"""

# 目标变量
target_var = 'feature_shape'

func_text1 = """
def mlm_sample_text(params, x, random_documents=False):
    seed = params.get('seed', None)
    ctx_len = params["n_ctx"]
    assert 'mlm_mask_id' in params, 'the key `mlm_mask_id` must be set on your config to do masked language model training, specifying the id of the reserved mask token'

    mask_id = params['mlm_mask_id']
    cls_token_id = params.get('mlm_cls_token_id', None)
    num_tokens = params.get('n_vocab', None)

    mask_ignore_ids = set(params.get('mlm_mask_ignore_ids', []))
    mask_ignore_ids.add(cls_token_id)

    mask_prob = params.get('mlm_mask_prob', 0.15)
    same_token_prob = params.get('mlm_same_token_prob', 0.10)
    random_token_prob = params.get('mlm_random_token_prob', 0.)

    seq_len = ctx_len if cls_token_id is None else (ctx_len - 1)

    if random_documents:
        s = tf.size(x)
        r = tf.random.uniform([], maxval=(s - seq_len), dtype=tf.dtypes.int32, seed=seed)
        r1 = tf.range(r, r + seq_len)
"""
target_var1 = """r1"""

# 提取传递关系
relevant_code = extract_relevant_code(func_text1, target_var1)
# print(relevant_code)
for line in relevant_code:
    print(line.strip())
