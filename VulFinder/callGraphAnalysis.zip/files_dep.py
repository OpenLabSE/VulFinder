import os
import ast
from graphviz import Digraph
'''
分析代码文件之间的调用关系并生成调用图
'''


def get_imports(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        tree = ast.parse(file.read(), filename=filepath)

    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.append(node.module)

    return imports


def analyze_project(directory):
    dependencies = {}
    project_root = os.path.abspath(directory)
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                filepath = os.path.join(root, file)
                module = os.path.relpath(filepath, directory).replace(os.sep, '.').rsplit('.', 1)[0]
                imports = get_imports(filepath)

                # 只保留项目自身的导入
                local_imports = []
                for imp in imports:
                    imp_path = imp.replace('.', os.sep) + '.py'
                    if os.path.exists(os.path.join(project_root, imp_path)):
                        local_imports.append(imp)

                dependencies[module] = local_imports

    return dependencies

def create_dependency_graph(dependencies):
    dot = Digraph(comment='Dependency Graph')
    for module, imports in dependencies.items():
        for imp in imports:
            dot.edge(module, imp)
    dot.render('albert', format='png', view=True)


project_directory = 'D:\\reserach\\LLM-sc-vul-case\\albert'
dependencies = analyze_project(project_directory)
for module, imports in dependencies.items():
    print(f'{module} imports: {imports}')

create_dependency_graph(dependencies)
