import ast
from graphviz import Digraph

# 自定义节点访问器以提取函数定义和调用
class FunctionCallVisitor(ast.NodeVisitor):
    def __init__(self):
        self.functions = {}
        self.current_function = None
        self.current_class = None

    def visit_FunctionDef(self, node):
        # 保存当前函数的上下文
        parent_function = self.current_function
        self.current_function = f"{self.current_class}.{node.name}" if self.current_class else node.name
        if self.current_function not in self.functions:
            self.functions[self.current_function] = []
        self.generic_visit(node)
        # 恢复上下文
        self.current_function = parent_function

    def visit_ClassDef(self, node):
        # 保存当前类的上下文
        parent_class = self.current_class
        self.current_class = node.name
        self.generic_visit(node)
        # 恢复上下文
        self.current_class = parent_class

    def visit_Call(self, node):
        if self.current_function:
            if isinstance(node.func, ast.Name):
                self.functions[self.current_function].append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                value_id = node.func.value.id if isinstance(node.func.value, ast.Name) else None
                if value_id:
                    self.functions[self.current_function].append(f"{value_id}.{node.func.attr}")
                else:
                    self.functions[self.current_function].append(node.func.attr)
        self.generic_visit(node)


def parse_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        tree = ast.parse(file.read())
    visitor = FunctionCallVisitor()
    visitor.visit(tree)
    return visitor.functions


def build_call_graph(function_calls):
    dot = Digraph(comment='Function Call Graph')
    for function, calls in function_calls.items():
        dot.node(function, function)
        for call in calls:
            dot.node(call, call)
            dot.edge(function, call)
    return dot


def generate_function_call_graph(file_path, output_path):
    function_calls = parse_file(file_path)
    call_graph = build_call_graph(function_calls)
    call_graph.render(output_path, format='png')
    return function_calls


def find_call_paths(function_calls, target_function):
    paths = []
    visited = set()

    def dfs(current_function, path):
        if current_function in visited:
            return
        visited.add(current_function)
        path.append(current_function)
        if current_function == target_function:
            paths.append(path[:])
        else:
            if current_function in function_calls:
                for called_function in function_calls[current_function]:
                    dfs(called_function, path)
        path.pop()
        visited.remove(current_function)

    for func in function_calls:
        dfs(func, [])

    # 只保留不重复的调用路径
    unique_paths = []
    seen = set()
    for path in paths:
        path_tuple = tuple(path)
        if path_tuple not in seen:
            unique_paths.append(path)
            seen.add(path_tuple)

    # return unique_paths
    return remove_suffix_paths(unique_paths)


def is_suffix(list1, list2):
    """
    检查list2是否是list1的后缀列表
    """
    if len(list2) > len(list1):
        return False
    return list1[-len(list2):] == list2


def remove_suffix_paths(list_of_lists):
    """
    删除二维列表中的后缀列表
    """
    n = len(list_of_lists)
    keep = set(range(n))

    for i in range(n):
        for j in range(n):
            if i != j and j in keep and is_suffix(list_of_lists[i], list_of_lists[j]):
                keep.discard(j)

    result = [list_of_lists[i] for i in keep]
    return result


def merge_path(paths1, paths2):
    final_paths = []
    for path1 in paths1:
        for path2 in paths2:
            path2[0] = path2[0].replace('.__init__', '')
            if path1[-1].split('.')[1] == path2[0]:
                final_paths.append(path1 + path2[1:])
    return final_paths


if __name__ == '__main__':
    # 使用示例
    run_classifier_file_path = 'D:/reserach/LLM-sc-vul-case/albert/modeling.py'  # 替换为run_classifier.py文件的实际路径
    output_file_path = 'data/modeling/modeling'
    function_calls = generate_function_call_graph(run_classifier_file_path, output_file_path)
    print(f"Function call graph generated and saved as {output_file_path}.png")

    # 查找BertModel的调用路径
    # target_function = "lambada_input"  ##"modeling.BertModel"
    target_functions = ["einsum_via_matmul"]
    for target_function in target_functions:
        call_paths = find_call_paths(function_calls, target_function)
    # call_paths3 = find_call_paths(function_calls, "model_fn_builder")
    #
    # call_paths1 = []
    # for path in call_paths:
    #     call_paths1.append(call_paths3[0] + path)

        for path in call_paths:
            print(" -> ".join(path))


    # modeling_file_path = 'data/input/modeling.py'  # 替换为run_classifier.py文件的实际路径
    # output_file_path = 'data/modeling'
    # function_calls = generate_function_call_graph(modeling_file_path, output_file_path)
    # print(f"Function call graph generated and saved as {output_file_path}.png\n")
    #
    # # 查找embedding_lookup的调用路径
    # target_functions = ["reshape_to_matrix", "attention_layer", "transformer_model", "transpose_for_scores", ]
    # for target_function in target_functions:
    #     call_paths2 = find_call_paths(function_calls, target_function)
    #
    #     final_paths = merge_path(call_paths1, call_paths2)
    #     print(f"Call paths to {target_function}:")
    #     for path in final_paths:
    #         print(" -> ".join(path))